export type Language = 'en' | 'hi' | 'mr';

export type UserRole = 'coordinator' | 'iqac_member' | 'faculty' | 'admin' | 'student';

export interface User {
  id: string;
  name: string;
  email: string;
  institution: string;
  role: UserRole;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  language?: Language;
  sources?: { title: string; url: string; verified?: boolean }[];
  feedback?: 'helpful' | 'unhelpful' | null;
  suggestedQuestions?: string[];
  isError?: boolean;
}

export interface NaacCriterion {
  id: number;
  number: string;
  title: string;
  titleHi: string;
  titleMr: string;
  shortDescription: string;
  detailedOverview: string;
  weightageAffiliatedUG: number;
  weightageAffiliatedPG: number;
  weightageAutonomous: number;
  weightageUniversity: number;
  keyIndicators: {
    code: string;
    name: string;
    description: string;
    coreDocuments: string[];
  }[];
  typicalEvidence: string[];
  preparationChecklist: string[];
  faqs: { question: string; answer: string }[];
  manualReferences: { title: string; url: string; note: string }[];
}

export type DocumentStatus = 'Not Started' | 'In Progress' | 'Completed';

export interface DocumentItem {
  id: string;
  title: string;
  description: string;
  criterionId: number; // 1 to 7 or 0 for General IQAC
  category: string;
  academicYear: string;
  responsibleDepartment: string;
  status: DocumentStatus;
  lastUpdated: string;
  notes: string;
  verifiedMandatory: boolean;
}

export interface AccreditationStage {
  id: number;
  stepNumber: number;
  title: string;
  shortDescription: string;
  estimatedTimeline: string;
  detailedGuidance: string[];
  criticalDocuments: string[];
  dosAndDonts: {
    dos: string[];
    donts: string[];
  };
  officialLink?: string;
  completed?: boolean;
}

export interface OfficialResource {
  id: string;
  title: string;
  category: 'Manual' | 'Guideline' | 'Circular' | 'Format' | 'Portal';
  description: string;
  url: string;
  publicationDate: string;
  lastVerifiedDate: string;
  isVerified: boolean;
  fileType?: string;
}

export interface FAQItem {
  id: string;
  category: string;
  question: string;
  answer: string;
  officialRef?: string;
  tags: string[];
}

export interface Announcement {
  id: string;
  title: string;
  date: string;
  summary: string;
  link?: string;
  badge: 'Notice' | 'Manual Update' | 'Advisory' | 'Framework';
  isActive: boolean;
}

export interface AdminStats {
  totalQueries: number;
  helpfulCount: number;
  unhelpfulCount: number;
  languageDistribution: Record<Language, number>;
  totalDocuments: number;
  completedDocuments: number;
  totalUsers: number;
  recentQueries: {
    query: string;
    timestamp: string;
    language: Language;
    hasFeedback: boolean;
  }[];
}
