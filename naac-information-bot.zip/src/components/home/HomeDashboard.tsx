import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  Bot,
  Layers,
  FileCheck2,
  GitFork,
  BookOpen,
  HelpCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ExternalLink,
  ChevronRight,
  Flame,
  Award,
  Bell
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Announcement, FAQItem } from '../../types';

export const HomeDashboard: React.FC = () => {
  const { setActiveTab, startChatWithQuery, setSelectedCriterionId } = useApp();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [faqs, setFaqs] = useState<FAQItem[]>([]);

  useEffect(() => {
    Promise.all([api.getAnnouncements(), api.getFaqs()])
      .then(([ann, f]) => {
        setAnnouncements(ann);
        setFaqs(f.slice(0, 4));
      })
      .catch(() => {});
  }, []);

  const popularTopics = [
    { title: 'What is NAAC?', query: 'What is NAAC and what is its role in higher education accreditation?' },
    { title: 'Role of IQAC', query: 'What is the role and statutory composition of the IQAC in a college?' },
    { title: 'SSR vs AQAR', query: 'Explain the complete difference between SSR (Self Study Report) and AQAR.' },
    { title: '7 Assessment Criteria', query: 'List and explain all seven NAAC assessment criteria with their core focus.' },
    { title: 'DVV Process & Clarifications', query: 'What is the DVV process in NAAC and how should an institution answer clarifications?' },
    { title: 'Student Satisfaction Survey (SSS)', query: 'How is the online Student Satisfaction Survey conducted by NAAC?' },
  ];

  const dashboardCards = [
    {
      title: 'Ask NAAC AI Assistant',
      description: 'Conversational AI guidance in English, Hindi, and Marathi for any accreditation or criterion query.',
      icon: <Bot className="w-6 h-6 text-teal-600" />,
      action: () => setActiveTab('chat'),
      badge: 'Gemini 3.8',
      color: 'border-teal-500/40 bg-teal-50/40 dark:bg-teal-950/20'
    },
    {
      title: 'Explore 7 Assessment Criteria',
      description: 'Detailed analysis of Curricular Aspects, Teaching-Learning, Research, Infrastructure, and more.',
      icon: <Layers className="w-6 h-6 text-emerald-600" />,
      action: () => setActiveTab('criteria'),
      badge: '1000 Marks',
      color: 'border-emerald-500/40 bg-emerald-50/40 dark:bg-emerald-950/20'
    },
    {
      title: 'Documentation Guide & Checklist',
      description: 'Comprehensive evidence tracker, department logs, and CSV/PDF export for DVV audit preparedness.',
      icon: <FileCheck2 className="w-6 h-6 text-indigo-600" />,
      action: () => setActiveTab('documents'),
      badge: 'Interactive',
      color: 'border-indigo-500/40 bg-indigo-50/40 dark:bg-indigo-950/20'
    },
    {
      title: 'Accreditation Process Journey',
      description: 'Interactive 8-stage roadmap from IIQA eligibility to Peer Team Visit and post-accreditation AQARs.',
      icon: <GitFork className="w-6 h-6 text-amber-600" />,
      action: () => setActiveTab('process'),
      badge: 'Step-by-Step',
      color: 'border-amber-500/40 bg-amber-50/40 dark:bg-amber-950/20'
    },
    {
      title: 'IQAC Resources & Benchmarks',
      description: 'Quarterly minutes templates, stakeholder feedback ATRs, and Academic Administrative Audit (AAA).',
      icon: <Award className="w-6 h-6 text-purple-600" />,
      action: () => startChatWithQuery('What are the best practices for IQAC meetings, minutes, and continuous quality initiatives?'),
      badge: 'Best Practices',
      color: 'border-purple-500/40 bg-purple-50/40 dark:bg-purple-950/20'
    },
    {
      title: 'Official NAAC Resources',
      description: 'Verified repository of RAF manuals, DVV standard operating procedures, and government circulars.',
      icon: <BookOpen className="w-6 h-6 text-cyan-600" />,
      action: () => setActiveTab('resources'),
      badge: 'Verified Links',
      color: 'border-cyan-500/40 bg-cyan-50/40 dark:bg-cyan-950/20'
    },
  ];

  return (
    <div className="space-y-10 max-w-7xl mx-auto pb-6">
      {/* Hero Section */}
      <section className="relative rounded-3xl bg-gradient-to-br from-teal-900 via-slate-900 to-teal-950 text-white p-8 sm:p-12 md:p-16 overflow-hidden shadow-xl border border-teal-800/40">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-500/20 border border-teal-400/30 text-teal-300 text-xs font-bold tracking-wide">
            <Sparkles className="w-4 h-4 text-teal-300" />
            <span>AI-Powered Quality & Accreditation Assistance</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight leading-tight">
            Your Intelligent Guide to <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-emerald-300 to-teal-100">
              NAAC Accreditation
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            Understand NAAC criteria, prepare documentation, and simplify institutional quality assurance with AI-powered assistance. Grounded in official manuals and standard operating procedures.
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
            <button
              onClick={() => setActiveTab('chat')}
              className="px-6 py-3.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold text-sm transition-all shadow-lg shadow-teal-500/25 flex items-center justify-center gap-2 group cursor-pointer"
            >
              <Bot className="w-5 h-5 text-slate-950" />
              <span>Ask NAAC AI</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            <button
              onClick={() => setActiveTab('criteria')}
              className="px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-sm transition-all border border-white/20 backdrop-blur-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <Layers className="w-5 h-5 text-teal-300" />
              <span>Explore NAAC Criteria</span>
            </button>
          </div>

          {/* Key tags */}
          <div className="pt-4 flex items-center gap-4 text-xs text-teal-200/80 flex-wrap">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-teal-400" />
              7 Assessment Criteria
            </span>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-teal-400" />
              DVV & SSS Protocols
            </span>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-teal-400" />
              English, Hindi & Marathi
            </span>
          </div>
        </div>
      </section>

      {/* Official Announcement Ticker */}
      {announcements.length > 0 && (
        <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <Bell className="w-4 h-4 text-amber-500 shrink-0" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white">
              Official NAAC Notices & Framework Updates
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {announcements.slice(0, 3).map((ann) => (
              <div
                key={ann.id}
                className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] mb-1.5">
                    <span className="font-extrabold px-1.5 py-0.5 rounded-sm bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300">
                      {ann.badge}
                    </span>
                    <span className="text-slate-400">{ann.date}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 line-clamp-2">
                    {ann.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                    {ann.summary}
                  </p>
                </div>

                <a
                  href={ann.link || 'https://www.naac.gov.in/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-flex items-center gap-1 text-[11px] font-bold text-teal-600 dark:text-teal-400 hover:underline"
                >
                  <span>Official Notice</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Dashboard 6 Core Action Cards */}
      <section className="space-y-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
            Comprehensive Accreditation Modules
          </h2>
          <p className="text-xs text-slate-500">
            Dedicated tools tailored for NAAC Coordinators, IQAC Members, Faculty, and Administrators
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {dashboardCards.map((card, idx) => (
            <div
              key={idx}
              onClick={card.action}
              className={`p-6 rounded-2xl border transition-all cursor-pointer hover:shadow-md hover:-translate-y-0.5 flex flex-col justify-between bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 group`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center border border-slate-200/60 dark:border-slate-700/60 shadow-2xs group-hover:scale-105 transition-transform">
                    {card.icon}
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    {card.badge}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors">
                  {card.title}
                </h3>

                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {card.description}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-teal-600 dark:text-teal-400">
                <span>Access Module</span>
                <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Popular Topics / Recently Explored Queries */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-extrabold text-slate-900 dark:text-white uppercase tracking-wider">
            Popular NAAC Consultation Queries
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {popularTopics.map((item, idx) => (
            <button
              key={idx}
              onClick={() => startChatWithQuery(item.query)}
              className="text-left p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 hover:border-teal-400 dark:hover:border-teal-600 hover:bg-teal-50/50 dark:hover:bg-teal-950/30 transition-all flex items-center justify-between group"
            >
              <div>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-teal-700 dark:group-hover:text-teal-300">
                  {item.title}
                </p>
                <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                  {item.query}
                </p>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-600 shrink-0 group-hover:translate-x-1 transition-transform ml-2" />
            </button>
          ))}
        </div>
      </section>

      {/* Quick FAQ Preview */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
              Frequently Asked Questions
            </h2>
            <p className="text-xs text-slate-500">
              Clear answers to fundamental NAAC accreditation questions
            </p>
          </div>
          <button
            onClick={() => setActiveTab('faq')}
            className="text-xs font-bold text-teal-600 hover:underline flex items-center gap-1"
          >
            <span>View All FAQs</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {faqs.map((faq) => (
            <div
              key={faq.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs space-y-2 flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] font-bold text-teal-600 uppercase tracking-wider">
                  {faq.category}
                </span>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white mt-1">
                  {faq.question}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                  {faq.answer}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-[10px] text-slate-400">{faq.officialRef}</span>
                <button
                  onClick={() => startChatWithQuery(faq.question)}
                  className="font-bold text-teal-600 hover:underline flex items-center gap-1 text-[11px]"
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>Ask AI details</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
