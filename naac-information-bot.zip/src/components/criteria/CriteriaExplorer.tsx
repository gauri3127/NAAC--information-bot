import React, { useState, useMemo } from 'react';
import {
  Layers,
  Search,
  BookOpen,
  CheckSquare,
  HelpCircle,
  ExternalLink,
  Bot,
  ChevronRight,
  Award,
  Info,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { NAAC_CRITERIA_DATA } from '../../data/naacKnowledge';
import { useApp } from '../../context/AppContext';
import { NaacCriterion } from '../../types';

export const CriteriaExplorer: React.FC = () => {
  const { language, startChatWithQuery, selectedCriterionId, setSelectedCriterionId } = useApp();
  const [activeCriterionId, setActiveCriterionId] = useState<number>(selectedCriterionId || 1);
  const [searchQuery, setSearchQuery] = useState('');
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const activeCriterion: NaacCriterion = useMemo(() => {
    return NAAC_CRITERIA_DATA.find(c => c.id === activeCriterionId) || NAAC_CRITERIA_DATA[0];
  }, [activeCriterionId]);

  // Filter criteria based on search query
  const filteredCriteria = useMemo(() => {
    if (!searchQuery.trim()) return NAAC_CRITERIA_DATA;
    const q = searchQuery.toLowerCase();
    return NAAC_CRITERIA_DATA.filter(c =>
      c.title.toLowerCase().includes(q) ||
      c.number.toLowerCase().includes(q) ||
      c.shortDescription.toLowerCase().includes(q) ||
      c.keyIndicators.some(k => k.name.toLowerCase().includes(q) || k.description.toLowerCase().includes(q))
    );
  }, [searchQuery]);

  const toggleCheck = (itemKey: string) => {
    setCheckedItems(prev => ({ ...prev, [itemKey]: !prev[itemKey] }));
  };

  const getLocalizedTitle = (criterion: NaacCriterion) => {
    if (language === 'hi') return criterion.titleHi;
    if (language === 'mr') return criterion.titleMr;
    return criterion.title;
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-emerald-700 rounded-2xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-teal-200 text-xs font-semibold mb-3">
            <Layers className="w-4 h-4" />
            <span>NAAC Revised Accreditation Framework (RAF)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            The Seven NAAC Assessment Criteria
          </h1>
          <p className="mt-2 text-sm sm:text-base text-teal-100 leading-relaxed">
            Understand key indicators, quantitative & qualitative metric requirements, institutional weightages, and core documentation for your accreditation cycle.
          </p>

          {/* Quick Notice */}
          <div className="mt-4 flex items-center gap-2 text-xs text-teal-200 bg-teal-900/40 border border-teal-500/30 px-3 py-2 rounded-xl">
            <Info className="w-4 h-4 shrink-0 text-teal-300" />
            <span>
              Weightages represent the standard 1000-mark framework. Confirm specific metrics for Autonomous colleges or Universities in the official manual.
            </span>
          </div>
        </div>
      </div>

      {/* Main 2-Column Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Criteria Selector List & Search */}
        <div className="lg:col-span-4 space-y-4">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search criteria or metrics..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-teal-500 transition-colors shadow-2xs"
            />
          </div>

          {/* Criteria Cards */}
          <div className="space-y-2">
            {filteredCriteria.map((criterion) => {
              const isActive = criterion.id === activeCriterionId;
              return (
                <button
                  key={criterion.id}
                  onClick={() => {
                    setActiveCriterionId(criterion.id);
                    setSelectedCriterionId(criterion.id);
                  }}
                  className={`w-full text-left p-3.5 rounded-xl transition-all border flex items-center justify-between ${
                    isActive
                      ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-500 text-teal-900 dark:text-teal-200 shadow-xs'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                        isActive
                          ? 'bg-teal-600 text-white shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {criterion.id}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
                          {criterion.number}
                        </span>
                        <span className="text-[10px] font-semibold text-slate-400">
                          {criterion.weightageAffiliatedUG} Marks (UG)
                        </span>
                      </div>
                      <h3 className="text-xs font-bold text-slate-900 dark:text-white mt-0.5">
                        {getLocalizedTitle(criterion)}
                      </h3>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                        {criterion.shortDescription}
                      </p>
                    </div>
                  </div>
                  <ChevronRight
                    className={`w-4 h-4 shrink-0 transition-transform ${
                      isActive ? 'text-teal-600 translate-x-1' : 'text-slate-300 dark:text-slate-600'
                    }`}
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed Breakdown of Selected Criterion */}
        <div className="lg:col-span-8 space-y-6">
          {/* Criterion Overview Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300 uppercase tracking-wider">
                  {activeCriterion.number}
                </span>
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-white mt-2">
                  {getLocalizedTitle(activeCriterion)}
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  {activeCriterion.shortDescription}
                </p>
              </div>

              {/* Ask AI button for this specific criterion */}
              <button
                onClick={() =>
                  startChatWithQuery(
                    `Explain ${activeCriterion.number}: ${activeCriterion.title} in detail. What are the key indicators, documentation required, and scoring tips?`
                  )
                }
                className="shrink-0 flex items-center gap-2 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs transition-colors shadow-xs"
              >
                <Bot className="w-4 h-4" />
                <span>Ask AI About Criterion {activeCriterion.id}</span>
              </button>
            </div>

            {/* Detailed Description */}
            <div className="mt-4 text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              {activeCriterion.detailedOverview}
            </div>

            {/* Weightage Grid */}
            <div className="mt-5">
              <h4 className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">
                Comparative Marks Weightage (out of 1000)
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center">
                  <p className="text-[10px] text-slate-500 font-medium">Affiliated UG</p>
                  <p className="text-lg font-black text-teal-700 dark:text-teal-300">
                    {activeCriterion.weightageAffiliatedUG}
                  </p>
                </div>
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center">
                  <p className="text-[10px] text-slate-500 font-medium">Affiliated PG</p>
                  <p className="text-lg font-black text-teal-700 dark:text-teal-300">
                    {activeCriterion.weightageAffiliatedPG}
                  </p>
                </div>
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center">
                  <p className="text-[10px] text-slate-500 font-medium">Autonomous</p>
                  <p className="text-lg font-black text-teal-700 dark:text-teal-300">
                    {activeCriterion.weightageAutonomous}
                  </p>
                </div>
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center">
                  <p className="text-[10px] text-slate-500 font-medium">University</p>
                  <p className="text-lg font-black text-teal-700 dark:text-teal-300">
                    {activeCriterion.weightageUniversity}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Key Indicators (Sub-criteria) */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-teal-600" />
              <span>Key Indicators (KIs) & Primary Core Documents</span>
            </h3>

            <div className="space-y-3">
              {activeCriterion.keyIndicators.map((ki) => (
                <div
                  key={ki.code}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-extrabold px-2 py-0.5 rounded-md bg-teal-700 text-white">
                      KI {ki.code}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      {ki.name}
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
                    {ki.description}
                  </p>

                  <div className="mt-3 pt-2.5 border-t border-slate-200/70 dark:border-slate-700/60">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                      Core Evidence Documents:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {ki.coreDocuments.map((doc, idx) => (
                        <span
                          key={idx}
                          className="text-[11px] px-2.5 py-1 rounded-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-medium"
                        >
                          • {doc}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Typical Evidence and Preparation Checklist */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Typical Evidence */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2 uppercase tracking-wider">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>Typical Evidentiary Records</span>
              </h3>
              <ul className="space-y-2">
                {activeCriterion.typicalEvidence.map((ev, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                    <span>{ev}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Preparation Checklist */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2 uppercase tracking-wider">
                <CheckSquare className="w-4 h-4 text-teal-600" />
                <span>Interactive Readiness Checklist</span>
              </h3>
              <div className="space-y-2">
                {activeCriterion.preparationChecklist.map((item, i) => {
                  const key = `c${activeCriterion.id}-chk-${i}`;
                  const isChecked = !!checkedItems[key];
                  return (
                    <label
                      key={i}
                      className={`flex items-start gap-2.5 p-2 rounded-lg cursor-pointer transition-colors text-xs ${
                        isChecked
                          ? 'bg-teal-50 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 line-through opacity-80'
                          : 'hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleCheck(key)}
                        className="mt-0.5 rounded text-teal-600 focus:ring-teal-500"
                      />
                      <span className="leading-normal">{item}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Criterion Specific FAQs */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-teal-600" />
              <span>Criterion {activeCriterion.id} Frequently Asked Questions</span>
            </h3>

            <div className="space-y-3">
              {activeCriterion.faqs.map((faq, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30"
                >
                  <p className="text-xs font-bold text-slate-900 dark:text-white flex items-start gap-2">
                    <span className="text-teal-600">Q:</span>
                    <span>{faq.question}</span>
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 pl-4 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
