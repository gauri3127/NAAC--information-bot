import React, { useState } from 'react';
import { X, ShieldCheck, UserCheck, Lock, Building, Mail, User, Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { login, register, showToast } = useApp();
  const [isRegisterMode, setIsRegisterMode] = useState(false);

  // Sign In State
  const [email, setEmail] = useState('');

  // Register State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regInstitution, setRegInstitution] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('coordinator');

  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    try {
      setIsLoading(true);
      await login(email.trim());
      onClose();
    } catch {
      // Error handled in context
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regEmail.trim()) return;
    try {
      setIsLoading(true);
      await register(regName.trim(), regEmail.trim(), regInstitution.trim(), regRole);
      onClose();
    } catch {
      // Error handled in context
    } finally {
      setIsLoading(false);
    }
  };

  const selectDemoRole = async (demoEmail: string) => {
    try {
      setIsLoading(true);
      await login(demoEmail);
      onClose();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-full max-w-md p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
              {isRegisterMode ? 'Institutional Registration' : 'Sign In to NAAC Portal'}
            </h2>
            <p className="text-xs text-slate-500">
              Access your saved checklists, institutional progress, and queries
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1-Click Fast Demo Switcher */}
        <div className="p-3.5 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800/60 space-y-2">
          <p className="text-[10px] font-bold uppercase tracking-wider text-teal-800 dark:text-teal-300 flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            Quick Demo Accounts (1-Click Test)
          </p>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => selectDemoRole('coordinator@college.edu')}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-teal-200 dark:border-teal-700 text-teal-900 dark:text-teal-200 hover:bg-teal-100 font-medium text-left"
            >
              <span className="font-bold block text-[11px]">NAAC Coordinator</span>
              <span className="text-[10px] text-slate-400">Gauri Patil</span>
            </button>

            <button
              onClick={() => selectDemoRole('admin@college.edu')}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-amber-200 dark:border-amber-700 text-amber-900 dark:text-amber-200 hover:bg-amber-100 font-medium text-left"
            >
              <span className="font-bold block text-[11px]">Administrator</span>
              <span className="text-[10px] text-slate-400">Full System Access</span>
            </button>

            <button
              onClick={() => selectDemoRole('iqac@college.edu')}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-teal-200 dark:border-teal-700 text-teal-900 dark:text-teal-200 hover:bg-teal-100 font-medium text-left"
            >
              <span className="font-bold block text-[11px]">IQAC Member</span>
              <span className="text-[10px] text-slate-400">Prof. Anjali Kulkarni</span>
            </button>

            <button
              onClick={() => selectDemoRole('faculty@college.edu')}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-teal-200 dark:border-teal-700 text-teal-900 dark:text-teal-200 hover:bg-teal-100 font-medium text-left"
            >
              <span className="font-bold block text-[11px]">Faculty Member</span>
              <span className="text-[10px] text-slate-400">Criterion Contributor</span>
            </button>
          </div>
        </div>

        {/* Form */}
        {!isRegisterMode ? (
          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Institutional Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. coordinator@college.edu"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs transition-colors shadow-xs"
            >
              {isLoading ? 'Signing In...' : 'Sign In'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Full Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="Dr. S. K. Patel"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="coordinator@college.edu"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                College / Institution Name
              </label>
              <div className="relative">
                <Building className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={regInstitution}
                  onChange={(e) => setRegInstitution(e.target.value)}
                  placeholder="e.g. National College of Excellence"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Institutional Role
              </label>
              <select
                value={regRole}
                onChange={(e) => setRegRole(e.target.value as UserRole)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500 font-medium"
              >
                <option value="coordinator">NAAC Steering Committee Coordinator</option>
                <option value="iqac_member">IQAC Committee Member</option>
                <option value="faculty">Faculty / Criterion Head</option>
                <option value="admin">College Administrator / Principal</option>
                <option value="student">Student Representative</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs transition-colors shadow-xs"
            >
              {isLoading ? 'Registering...' : 'Complete Registration'}
            </button>
          </form>
        )}

        {/* Toggle sign in / register */}
        <div className="text-center pt-2">
          <button
            onClick={() => setIsRegisterMode(prev => !prev)}
            className="text-xs text-teal-600 dark:text-teal-400 font-semibold hover:underline"
          >
            {isRegisterMode ? 'Already have an account? Sign In' : 'New institution? Create an account'}
          </button>
        </div>

        {/* Privacy notice */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 text-center flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
          <span>Server-side role authorization & private session handling.</span>
        </div>
      </div>
    </div>
  );
};
