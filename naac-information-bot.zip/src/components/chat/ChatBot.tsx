import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Bot,
  User,
  Copy,
  Check,
  Download,
  Trash2,
  ThumbsUp,
  ThumbsDown,
  Sparkles,
  ExternalLink,
  RefreshCw,
  AlertCircle,
  HelpCircle,
  Globe,
  FileText
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { ChatMessage, Language } from '../../types';

export const ChatBot: React.FC = () => {
  const { language, setLanguage, currentUser, chatInitialPrompt, setChatInitialPrompt } = useApp();

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: 'welcome-msg',
        sender: 'bot',
        text: `### Welcome to NAAC Information Bot!
I am your intelligent assistant for all aspects of **NAAC Accreditation**, **Assessment Criteria**, **IQAC Operations**, and **Institutional Quality Assurance**.

#### How can I assist you today?
- **7 Criteria:** Deep-dive into weightages, metrics, and documentation for Criteria 1 to 7.
- **Accreditation Cycle:** Guidance on IIQA, SSR submission, DVV clarifications, and Peer Team visits.
- **IQAC Functions:** Minutes, composition, Action Taken Reports (ATR), and AQAR preparation.
- **Evidence Management:** Required data templates, CA certificates, and geo-tagged proof guidelines.

*Feel free to ask in **English**, **हिन्दी (Hindi)**, or **मराठी (Marathi)**!*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language: 'en',
        suggestedQuestions: [
          'What is the difference between SSR and AQAR?',
          'What are the 7 criteria of NAAC assessment?',
          'What is the role and composition of the IQAC?',
          'What documents are required for NAAC assessment?'
        ]
      }
    ];
  });

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // If there's an initial prompt from another page (e.g. FAQ or Dashboard)
  useEffect(() => {
    if (chatInitialPrompt) {
      handleSend(chatInitialPrompt);
      setChatInitialPrompt('');
    }
  }, [chatInitialPrompt]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async (messageText?: string) => {
    const textToSend = (messageText || input).trim();
    if (!textToSend || isLoading) return;

    const userMessage: ChatMessage = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      language
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Build conversation history (up to last 6 messages)
      const history = messages.slice(-6).map(m => ({
        sender: m.sender,
        text: m.text
      }));

      const res = await api.sendChatMessage({
        message: textToSend,
        language,
        history,
        userRole: currentUser?.role
      });

      const botMessage: ChatMessage = {
        id: res.logId || 'bot-' + Date.now(),
        sender: 'bot',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language,
        sources: res.sources,
        suggestedQuestions: res.suggestedQuestions,
        feedback: null
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: 'err-' + Date.now(),
        sender: 'bot',
        text: `**Notice:** Unable to generate response. ${err.message || 'Please verify your network connection or try again shortly.'}\n\nYou can also browse the verified **7 Criteria Explorer** or **Official Resource Center** in the sidebar.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 100);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleFeedback = async (messageId: string, type: 'helpful' | 'unhelpful') => {
    try {
      await api.sendFeedback(messageId, type);
      setMessages(prev =>
        prev.map(m => (m.id === messageId ? { ...m, feedback: type } : m))
      );
    } catch (err) {
      console.error('Failed to submit feedback', err);
    }
  };

  const exportAsPdf = (message: ChatMessage) => {
    try {
      const doc = new jsPDF();
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.text('NAAC Information Bot - Educational Guidance', 14, 20);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.text(`Generated on: ${new Date().toLocaleString()} | Language: ${language.toUpperCase()}`, 14, 28);
      doc.text('Source: https://www.naac.gov.in (Verify with current official manual)', 14, 34);

      doc.setDrawColor(200, 200, 200);
      doc.line(14, 38, 196, 38);

      doc.setFontSize(10);
      // Clean markdown tags for plain text rendering
      const cleanText = message.text
        .replace(/###\s?/g, '\n[SECTION] ')
        .replace(/####\s?/g, '\n- ')
        .replace(/\*\*/g, '')
        .replace(/\*/g, '');

      const splitText = doc.splitTextToSize(cleanText, 180);
      doc.text(splitText, 14, 46);

      doc.save(`NAAC_Guidance_${Date.now()}.pdf`);
    } catch (e) {
      console.error('PDF export error:', e);
    }
  };

  const clearChat = () => {
    if (window.confirm('Are you sure you want to clear this conversation?')) {
      setMessages([
        {
          id: 'welcome-msg',
          sender: 'bot',
          text: `Chat cleared. Ask me any question regarding NAAC criteria, IQAC, SSR, DVV, or institutional quality assurance in English, हिन्दी, or मराठी.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestedQuestions: [
            'What is the composition of the IQAC committee?',
            'What are the mandatory documents for Criterion 1?',
            'How is the Student Satisfaction Survey (SSS) conducted?'
          ]
        }
      ]);
    }
  };

  // Simple Markdown renderer for headings, lists, bold, tables
  const renderFormattedText = (rawText: string) => {
    const lines = rawText.split('\n');
    const elements: React.ReactNode[] = [];

    let inTable = false;
    let tableRows: string[][] = [];

    const flushTable = (keyIndex: number) => {
      if (tableRows.length > 0) {
        const header = tableRows[0];
        const body = tableRows.slice(1);
        elements.push(
          <div key={`table-${keyIndex}`} className="overflow-x-auto my-3 rounded-lg border border-slate-200 dark:border-slate-700">
            <table className="min-w-full text-xs text-left">
              <thead className="bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 uppercase font-bold">
                <tr>
                  {header.map((col, idx) => (
                    <th key={idx} className="px-3 py-2 border-b border-slate-200 dark:border-slate-700">
                      {col.trim()}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {body.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} className="px-3 py-2 text-slate-700 dark:text-slate-300">
                        {cell.trim()}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
        tableRows = [];
        inTable = false;
      }
    };

    lines.forEach((line, index) => {
      const trimmed = line.trim();

      // Check table row
      if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
        inTable = true;
        // Ignore markdown divider line |---|---|
        if (trimmed.includes('---')) return;
        const cols = trimmed.slice(1, -1).split('|');
        tableRows.push(cols);
        return;
      } else if (inTable) {
        flushTable(index);
      }

      if (trimmed.startsWith('### ')) {
        elements.push(
          <h3 key={index} className="text-sm font-bold text-teal-800 dark:text-teal-300 mt-3 mb-1.5 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
            <span>{trimmed.replace('### ', '')}</span>
          </h3>
        );
      } else if (trimmed.startsWith('#### ')) {
        elements.push(
          <h4 key={index} className="text-xs font-bold text-slate-900 dark:text-slate-100 mt-2 mb-1">
            {trimmed.replace('#### ', '')}
          </h4>
        );
      } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        const itemContent = trimmed.substring(2);
        elements.push(
          <li key={index} className="ml-4 list-disc text-xs text-slate-700 dark:text-slate-200 my-0.5 leading-relaxed">
            {formatInline(itemContent)}
          </li>
        );
      } else if (/^\d+\.\s/.test(trimmed)) {
        const num = trimmed.match(/^\d+\./)?.[0] || '1.';
        const itemContent = trimmed.replace(/^\d+\.\s/, '');
        elements.push(
          <div key={index} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-200 my-1 leading-relaxed">
            <span className="font-bold text-teal-600 dark:text-teal-400 shrink-0">{num}</span>
            <span>{formatInline(itemContent)}</span>
          </div>
        );
      } else if (trimmed === '') {
        elements.push(<div key={index} className="h-1.5" />);
      } else {
        elements.push(
          <p key={index} className="text-xs text-slate-700 dark:text-slate-200 my-1 leading-relaxed">
            {formatInline(trimmed)}
          </p>
        );
      }
    });

    if (inTable) {
      flushTable(lines.length);
    }

    return elements;
  };

  const formatInline = (text: string) => {
    // Process bold **text**
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-bold text-slate-900 dark:text-white">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-5xl mx-auto bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
      {/* Chat Header Bar */}
      <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                NAAC Guidance & Accreditation Assistant
              </h2>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Active • Gemini 3.8
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Answering NAAC questions grounded in official manuals, DVV SOPs & IQAC benchmarks
            </p>
          </div>
        </div>

        {/* Language selector & Clear chat */}
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center bg-slate-200/70 dark:bg-slate-700/60 p-0.5 rounded-lg text-[11px] font-semibold">
            {(['en', 'hi', 'mr'] as Language[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  language === lang
                    ? 'bg-white dark:bg-slate-800 text-teal-700 dark:text-teal-300 shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                {lang === 'en' ? 'English' : lang === 'hi' ? 'हिन्दी' : 'मराठी'}
              </button>
            ))}
          </div>

          <button
            onClick={clearChat}
            className="p-2 text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Clear Chat History"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map((message) => {
          const isUser = message.sender === 'user';
          return (
            <div
              key={message.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold shadow-xs ${
                  isUser
                    ? 'bg-teal-700 text-white'
                    : 'bg-gradient-to-tr from-teal-600 to-emerald-500 text-white'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div
                className={`max-w-[85%] sm:max-w-[80%] rounded-2xl p-4 shadow-xs ${
                  isUser
                    ? 'bg-teal-700 text-white rounded-tr-none'
                    : message.isError
                    ? 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200 rounded-tl-none'
                    : 'bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 text-slate-900 dark:text-white rounded-tl-none'
                }`}
              >
                {/* Bubble Text */}
                <div className="text-xs leading-relaxed">
                  {isUser ? (
                    <p className="whitespace-pre-wrap">{message.text}</p>
                  ) : (
                    renderFormattedText(message.text)
                  )}
                </div>

                {/* Sources if present */}
                {!isUser && message.sources && message.sources.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700/60">
                    <p className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                      <ExternalLink className="w-3 h-3 text-teal-600" />
                      Verified Official References
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {message.sources.map((src, i) => (
                        <a
                          key={i}
                          href={src.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[10px] font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-slate-800 transition-colors"
                        >
                          <span>{src.title}</span>
                          <ExternalLink className="w-2.5 h-2.5 opacity-60" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Actions: Copy, Export PDF, Feedback */}
                {!isUser && (
                  <div className="mt-3 pt-2.5 border-t border-slate-200/60 dark:border-slate-700/50 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="text-[10px]">{message.timestamp}</span>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleCopy(message.id, message.text)}
                        className="p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
                        title="Copy Response"
                      >
                        {copiedId === message.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <button
                        onClick={() => exportAsPdf(message)}
                        className="p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
                        title="Export as PDF"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>

                      <div className="w-px h-3 bg-slate-300 dark:bg-slate-700 mx-0.5" />

                      <button
                        onClick={() => handleFeedback(message.id, 'helpful')}
                        className={`p-1 rounded-md transition-colors ${
                          message.feedback === 'helpful'
                            ? 'text-teal-600 bg-teal-100 dark:bg-teal-900/40'
                            : 'hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-teal-600'
                        }`}
                        title="Helpful Answer"
                      >
                        <ThumbsUp className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleFeedback(message.id, 'unhelpful')}
                        className={`p-1 rounded-md transition-colors ${
                          message.feedback === 'unhelpful'
                            ? 'text-rose-600 bg-rose-100 dark:bg-rose-900/40'
                            : 'hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-rose-600'
                        }`}
                        title="Not Helpful"
                      >
                        <ThumbsDown className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Spinner Indicator */}
        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-2xl rounded-tl-none p-4 shadow-xs">
              <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-teal-600" />
                <span className="font-medium">
                  {language === 'hi'
                    ? 'नॅक मार्गदर्शिका उत्तर तैयार कर रहा है...'
                    : language === 'mr'
                    ? 'नॅक मार्गदर्शक उत्तर तयार करत आहे...'
                    : 'Analyzing NAAC criteria and official documentation...'}
                </span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Follow-up Questions Chips */}
      {messages.length > 0 && messages[messages.length - 1].suggestedQuestions && !isLoading && (
        <div className="px-5 py-2 bg-slate-50/80 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 overflow-x-auto">
          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-teal-500" />
            Suggested Questions
          </p>
          <div className="flex items-center gap-2 flex-nowrap sm:flex-wrap">
            {messages[messages.length - 1].suggestedQuestions?.map((sq, i) => (
              <button
                key={i}
                onClick={() => handleSend(sq)}
                className="whitespace-nowrap px-3 py-1 rounded-full text-xs bg-white dark:bg-slate-800 border border-teal-200 dark:border-teal-800/60 text-teal-800 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-slate-700 transition-colors shadow-2xs font-medium"
              >
                {sq}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Message Input Bar */}
      <div className="p-3 sm:p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
        <div className="flex items-end gap-2 bg-slate-50 dark:bg-slate-800/60 rounded-xl p-2 border border-slate-200 dark:border-slate-700 focus-within:border-teal-500 dark:focus-within:border-teal-400 transition-colors">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              language === 'hi'
                ? 'नॅक मूल्यांकन, मानदंड, आईक्यूएसी या दस्तावेजों पर प्रश्न पूछें...'
                : language === 'mr'
                ? 'नॅक मूल्यांकन, निकष, आयक्यूएसी किंवा पुराव्यांवर प्रश्न विचारा...'
                : 'Ask a question about NAAC criteria, IQAC, SSR, DVV, or documentation...'
            }
            rows={1}
            disabled={isLoading}
            className="flex-1 max-h-32 min-h-[38px] bg-transparent text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none resize-none px-2 py-1.5"
          />

          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isLoading}
            className="w-9 h-9 rounded-lg bg-teal-600 hover:bg-teal-700 disabled:opacity-40 disabled:hover:bg-teal-600 text-white flex items-center justify-center shrink-0 transition-colors shadow-xs"
            title="Send Message"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
          <span>Press Enter to send, Shift+Enter for new line</span>
          <span>Answers grounded in official NAAC manuals</span>
        </div>
      </div>
    </div>
  );
};
