import React, { useState, useEffect, useMemo } from 'react';
import {
  FileCheck2,
  Plus,
  Search,
  Filter,
  Download,
  Trash2,
  Edit2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  X,
  FileSpreadsheet,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { api } from '../../services/api';
import { DocumentItem, DocumentStatus } from '../../types';
import { useApp } from '../../context/AppContext';

export const DocumentGuide: React.FC = () => {
  const { showToast } = useApp();
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [selectedCriterion, setSelectedCriterion] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedYear, setSelectedYear] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [editingDoc, setEditingDoc] = useState<DocumentItem | null>(null);

  // Form State
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formCriterion, setFormCriterion] = useState('1');
  const [formCategory, setFormCategory] = useState('Academic Records');
  const [formYear, setFormYear] = useState('2025-2026');
  const [formDept, setFormDept] = useState('IQAC');
  const [formStatus, setFormStatus] = useState<DocumentStatus>('Not Started');
  const [formNotes, setFormNotes] = useState('');

  const loadDocuments = async () => {
    try {
      setLoading(true);
      const data = await api.getDocuments();
      setDocuments(data);
    } catch (err: any) {
      showToast('Failed to load documents', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDocuments();
  }, []);

  const filteredDocs = useMemo(() => {
    return documents.filter((doc) => {
      const matchCrit = selectedCriterion === 'all' || doc.criterionId.toString() === selectedCriterion;
      const matchStatus = selectedStatus === 'all' || doc.status === selectedStatus;
      const matchYear = selectedYear === 'all' || doc.academicYear === selectedYear;
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !searchQuery.trim() ||
        doc.title.toLowerCase().includes(q) ||
        doc.description.toLowerCase().includes(q) ||
        doc.responsibleDepartment.toLowerCase().includes(q) ||
        doc.category.toLowerCase().includes(q);

      return matchCrit && matchStatus && matchYear && matchSearch;
    });
  }, [documents, selectedCriterion, selectedStatus, selectedYear, searchQuery]);

  // Completion calculation
  const totalCount = documents.length;
  const completedCount = documents.filter(d => d.status === 'Completed').length;
  const inProgressCount = documents.filter(d => d.status === 'In Progress').length;
  const percentCompleted = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const openAddModal = () => {
    setEditingDoc(null);
    setFormTitle('');
    setFormDescription('');
    setFormCriterion('1');
    setFormCategory('Academic Records');
    setFormYear('2025-2026');
    setFormDept('IQAC');
    setFormStatus('Not Started');
    setFormNotes('');
    setModalOpen(true);
  };

  const openEditModal = (doc: DocumentItem) => {
    setEditingDoc(doc);
    setFormTitle(doc.title);
    setFormDescription(doc.description);
    setFormCriterion(doc.criterionId.toString());
    setFormCategory(doc.category);
    setFormYear(doc.academicYear);
    setFormDept(doc.responsibleDepartment);
    setFormStatus(doc.status);
    setFormNotes(doc.notes);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      showToast('Document title is required', 'error');
      return;
    }

    try {
      if (editingDoc) {
        const updated = await api.updateDocument(editingDoc.id, {
          title: formTitle,
          description: formDescription,
          criterionId: Number(formCriterion),
          category: formCategory,
          academicYear: formYear,
          responsibleDepartment: formDept,
          status: formStatus,
          notes: formNotes
        });
        setDocuments(prev => prev.map(d => (d.id === updated.id ? updated : d)));
        showToast('Document checklist item updated', 'success');
      } else {
        const created = await api.createDocument({
          title: formTitle,
          description: formDescription,
          criterionId: Number(formCriterion),
          category: formCategory,
          academicYear: formYear,
          responsibleDepartment: formDept,
          status: formStatus,
          notes: formNotes
        });
        setDocuments(prev => [created, ...prev]);
        showToast('Document added to checklist', 'success');
      }
      setModalOpen(false);
    } catch (err: any) {
      showToast(err.message || 'Operation failed', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this document checklist item?')) return;
    try {
      await api.deleteDocument(id);
      setDocuments(prev => prev.filter(d => d.id !== id));
      showToast('Document removed', 'info');
    } catch (err: any) {
      showToast('Failed to delete document', 'error');
    }
  };

  const toggleStatusDirect = async (doc: DocumentItem) => {
    const nextStatus: DocumentStatus =
      doc.status === 'Completed'
        ? 'Not Started'
        : doc.status === 'In Progress'
        ? 'Completed'
        : 'In Progress';

    try {
      const updated = await api.updateDocument(doc.id, { status: nextStatus });
      setDocuments(prev => prev.map(d => (d.id === updated.id ? updated : d)));
      showToast(`Status updated to ${nextStatus}`, 'success');
    } catch {
      showToast('Failed to update status', 'error');
    }
  };

  // Export to CSV
  const exportToCsv = () => {
    const headers = ['Criterion', 'Title', 'Category', 'Academic Year', 'Department', 'Status', 'Notes'];
    const rows = filteredDocs.map(d => [
      `Criterion ${d.criterionId}`,
      `"${d.title.replace(/"/g, '""')}"`,
      `"${d.category}"`,
      d.academicYear,
      `"${d.responsibleDepartment}"`,
      d.status,
      `"${(d.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `NAAC_Documentation_Checklist_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Checklist exported as CSV', 'success');
  };

  // Export to PDF
  const exportToPdf = () => {
    try {
      const doc = new jsPDF();
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.text('NAAC Accreditation - Documentation & Evidence Checklist', 14, 20);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.text(`Total Items: ${filteredDocs.length} | Completed: ${completedCount} (${percentCompleted}%)`, 14, 28);
      doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 34);

      doc.setDrawColor(200, 200, 200);
      doc.line(14, 38, 196, 38);

      let yPos = 46;
      filteredDocs.forEach((item, idx) => {
        if (yPos > 270) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text(`${idx + 1}. [Crit ${item.criterionId}] ${item.title}`, 14, yPos);
        yPos += 5;

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.text(`Dept: ${item.responsibleDepartment} | Year: ${item.academicYear} | Status: ${item.status}`, 18, yPos);
        yPos += 5;

        if (item.notes) {
          doc.setFontSize(8);
          doc.text(`Notes: ${item.notes}`, 18, yPos);
          yPos += 5;
        }
        yPos += 3;
      });

      doc.save(`NAAC_Evidence_Checklist_${Date.now()}.pdf`);
      showToast('Checklist exported as PDF', 'success');
    } catch (e) {
      console.error(e);
      showToast('Failed to export PDF', 'error');
    }
  };

  const categories = [
    'Academic Records',
    'Faculty Information',
    'Student Support',
    'Research & Publications',
    'Infrastructure',
    'Governance & Administration',
    'Extension & Collaborations',
    'Feedback & Quality'
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-slate-900 dark:text-white">
                Institutional Documentation & Evidence Checklist
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Track, audit, and organize 5-year NAAC evidentiary files across all 7 criteria
              </p>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
            <Info className="w-3.5 h-3.5 text-teal-600" />
            <span>Document items represent typical DVV audit requirements. Verify against applicable manual.</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={exportToCsv}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-2xs"
            title="Export CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={exportToPdf}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-2xs"
            title="Export PDF"
          >
            <Download className="w-4 h-4 text-teal-600" />
            <span>Export PDF</span>
          </button>

          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Add Checklist Item</span>
          </button>
        </div>
      </div>

      {/* Progress Metric Card */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <p className="text-xs text-slate-500 font-medium">Total Evidence Items</p>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">{totalCount}</p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-500 font-medium">Completed Files</p>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
          <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">{completedCount}</p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-500 font-medium">In Progress</p>
            <span className="w-2 h-2 rounded-full bg-amber-500" />
          </div>
          <p className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">{inProgressCount}</p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-2xs">
          <p className="text-xs text-slate-500 font-medium">Readiness Index</p>
          <div className="flex items-center justify-between mt-1">
            <p className="text-2xl font-black text-teal-700 dark:text-teal-300">{percentCompleted}%</p>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-900/50 text-teal-800 dark:text-teal-300">
              {percentCompleted > 70 ? 'High' : percentCompleted > 40 ? 'Moderate' : 'Early Phase'}
            </span>
          </div>
          {/* Progress bar */}
          <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
            <div
              className="bg-teal-600 h-full rounded-full transition-all duration-500"
              style={{ width: `${percentCompleted}%` }}
            />
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search document title, dept..."
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-teal-500"
          />
        </div>

        {/* Dropdowns */}
        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap sm:flex-nowrap">
          {/* Criterion filter */}
          <select
            value={selectedCriterion}
            onChange={(e) => setSelectedCriterion(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-teal-500 font-medium"
          >
            <option value="all">All Criteria (1-7)</option>
            {[1, 2, 3, 4, 5, 6, 7].map(c => (
              <option key={c} value={c}>Criterion {c}</option>
            ))}
          </select>

          {/* Status filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-teal-500 font-medium"
          >
            <option value="all">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="In Progress">In Progress</option>
            <option value="Not Started">Not Started</option>
          </select>

          {/* Year filter */}
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-teal-500 font-medium"
          >
            <option value="all">All Years</option>
            <option value="2025-2026">2025-2026</option>
            <option value="2024-2025">2024-2025</option>
            <option value="2023-2024">2023-2024</option>
            <option value="2021-2026">5-Year Period (2021-2026)</option>
          </select>
        </div>
      </div>

      {/* Document Table / Cards */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500">Loading document checklist...</div>
        ) : filteredDocs.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <FileCheck2 className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
            <p className="text-sm font-bold text-slate-700 dark:text-slate-300">No documents found matching filters</p>
            <p className="text-xs text-slate-400">Try adjusting your search criteria or add a new checklist item.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-xs text-left divide-y divide-slate-200 dark:divide-slate-800">
              <thead className="bg-slate-50 dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Criterion & Title</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Academic Year</th>
                  <th className="px-4 py-3">Department</th>
                  <th className="px-4 py-3">Notes & Remarks</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredDocs.map((doc) => {
                  return (
                    <tr key={doc.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors">
                      {/* Status Toggle */}
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <button
                          onClick={() => toggleStatusDirect(doc)}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold transition-all shadow-2xs ${
                            doc.status === 'Completed'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 hover:bg-emerald-200'
                              : doc.status === 'In Progress'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 hover:bg-amber-200'
                              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 hover:bg-slate-200'
                          }`}
                          title="Click to toggle status"
                        >
                          {doc.status === 'Completed' ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          ) : doc.status === 'In Progress' ? (
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                          ) : (
                            <AlertTriangle className="w-3.5 h-3.5 text-slate-400" />
                          )}
                          <span>{doc.status}</span>
                        </button>
                      </td>

                      {/* Criterion & Title */}
                      <td className="px-4 py-3.5 max-w-xs">
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <span className="text-[10px] font-extrabold px-1.5 py-0.2 rounded-sm bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300">
                            Crit {doc.criterionId}
                          </span>
                        </div>
                        <p className="font-bold text-slate-900 dark:text-white leading-tight">
                          {doc.title}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                          {doc.description}
                        </p>
                      </td>

                      {/* Category */}
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <span className="text-[11px] font-medium text-slate-700 dark:text-slate-300">
                          {doc.category}
                        </span>
                      </td>

                      {/* Year */}
                      <td className="px-4 py-3.5 whitespace-nowrap text-slate-600 dark:text-slate-400 font-mono text-[11px]">
                        {doc.academicYear}
                      </td>

                      {/* Department */}
                      <td className="px-4 py-3.5 whitespace-nowrap text-slate-700 dark:text-slate-300 font-medium">
                        {doc.responsibleDepartment}
                      </td>

                      {/* Notes */}
                      <td className="px-4 py-3.5 max-w-xs text-[11px] text-slate-500 dark:text-slate-400 truncate">
                        {doc.notes || '—'}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3.5 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openEditModal(doc)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            title="Edit Item"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(doc.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                            title="Delete Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 w-full max-w-lg p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {editingDoc ? 'Edit Checklist Item' : 'Add Document Checklist Item'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Document Title *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Mentor-Mentee Allocation Circular & Meeting Minutes"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Description / DVV Requirement
                </label>
                <textarea
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  rows={2}
                  placeholder="Brief note on what primary evidence is required for DVV..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Criterion
                  </label>
                  <select
                    value={formCriterion}
                    onChange={(e) => setFormCriterion(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                  >
                    {[1, 2, 3, 4, 5, 6, 7].map(c => (
                      <option key={c} value={c}>Criterion {c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Academic Year
                  </label>
                  <input
                    type="text"
                    value={formYear}
                    onChange={(e) => setFormYear(e.target.value)}
                    placeholder="2025-2026"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Responsible Dept
                  </label>
                  <input
                    type="text"
                    value={formDept}
                    onChange={(e) => setFormDept(e.target.value)}
                    placeholder="e.g. IQAC / Library"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Status
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as DocumentStatus)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500 font-semibold"
                  >
                    <option value="Not Started">Not Started</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Notes & Internal Verification Status
                </label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="e.g. Signed by Principal, uploaded to Google Drive folder"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold transition-colors shadow-xs"
                >
                  {editingDoc ? 'Save Changes' : 'Create Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
