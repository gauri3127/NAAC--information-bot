import React from 'react';
import {
  GraduationCap,
  Bot,
  Layers,
  FileCheck2,
  GitFork,
  BookOpen,
  HelpCircle,
  ShieldCheck,
  ExternalLink,
  CheckCircle2,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { useApp, NavTab } from '../../context/AppContext';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, currentUser } = useApp();

  const navItems: {
    id: NavTab;
    label: string;
    sublabel: string;
    icon: React.ReactNode;
    highlight?: boolean;
    badge?: string;
  }[] = [
    {
      id: 'home',
      label: 'Dashboard',
      sublabel: 'Overview & Highlights',
      icon: <GraduationCap className="w-5 h-5" />
    },
    {
      id: 'chat',
      label: 'Ask NAAC AI',
      sublabel: 'Smart Guidance in 3 Languages',
      icon: <Bot className="w-5 h-5" />,
      highlight: true,
      badge: 'Gemini AI'
    },
    {
      id: 'criteria',
      label: '7 Criteria Explorer',
      sublabel: 'Metrics & Sub-Criteria',
      icon: <Layers className="w-5 h-5" />
    },
    {
      id: 'documents',
      label: 'Documentation Guide',
      sublabel: 'Organize Evidence & Files',
      icon: <FileCheck2 className="w-5 h-5" />
    },
    {
      id: 'process',
      label: 'Accreditation Journey',
      sublabel: 'Step-by-step IIQA to Peer Visit',
      icon: <GitFork className="w-5 h-5" />
    },
    {
      id: 'resources',
      label: 'Official Resources',
      sublabel: 'Manuals, SOPs & Circulars',
      icon: <BookOpen className="w-5 h-5" />
    },
    {
      id: 'faq',
      label: 'Search & FAQ Hub',
      sublabel: 'Instant NAAC Answers',
      icon: <HelpCircle className="w-5 h-5" />
    },
  ];

  if (currentUser?.role === 'admin' || true) {
    navItems.push({
      id: 'admin',
      label: 'Admin & Analytics',
      sublabel: 'System Logs & Notices',
      icon: <ShieldCheck className="w-5 h-5 text-amber-500" />
    });
  }

  return (
    <aside className="w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between shrink-0 min-h-[calc(100vh-4rem)] p-3 transition-colors">
      <div className="space-y-4">
        {/* Quick Role Card */}
        <div className="p-3 rounded-xl bg-gradient-to-br from-teal-50 to-emerald-50 dark:from-teal-950/40 dark:to-emerald-950/30 border border-teal-100 dark:border-teal-800/50">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-teal-800 dark:text-teal-300 uppercase tracking-wider">
              Target Cycle
            </span>
            <span className="text-[10px] bg-teal-600 text-white font-bold px-1.5 py-0.5 rounded-full">
              RAF 2026
            </span>
          </div>
          <p className="text-xs font-bold text-slate-800 dark:text-slate-200 mt-1 truncate">
            {currentUser ? currentUser.institution : 'Affiliated Higher Education'}
          </p>
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-teal-700 dark:text-teal-400 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
            <span>Ready for SSR Preparation</span>
          </div>
        </div>

        {/* Navigation list */}
        <div className="space-y-1">
          <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            Navigation Menu
          </div>
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full group text-left px-3 py-2.5 rounded-xl transition-all flex items-center justify-between ${
                  isActive
                    ? 'bg-teal-700 text-white shadow-md shadow-teal-700/20 dark:bg-teal-600'
                    : item.highlight
                    ? 'bg-teal-50/70 hover:bg-teal-100/70 dark:bg-teal-950/30 dark:hover:bg-teal-950/60 text-teal-900 dark:text-teal-200 border border-teal-200/50 dark:border-teal-800/40'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`${
                      isActive
                        ? 'text-white'
                        : item.highlight
                        ? 'text-teal-600 dark:text-teal-400'
                        : 'text-slate-500 dark:text-slate-400 group-hover:text-teal-600 dark:group-hover:text-teal-400'
                    }`}
                  >
                    {item.icon}
                  </div>
                  <div className="truncate">
                    <p className={`text-xs font-bold leading-tight ${isActive ? 'text-white' : ''}`}>
                      {item.label}
                    </p>
                    <p
                      className={`text-[10px] truncate ${
                        isActive
                          ? 'text-teal-100'
                          : 'text-slate-400 dark:text-slate-500 group-hover:text-slate-600 dark:group-hover:text-slate-400'
                      }`}
                    >
                      {item.sublabel}
                    </p>
                  </div>
                </div>
                {item.badge ? (
                  <span
                    className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-white text-teal-800'
                        : 'bg-teal-600 text-white'
                    }`}
                  >
                    {item.badge}
                  </span>
                ) : (
                  <ChevronRight
                    className={`w-3.5 h-3.5 transition-transform ${
                      isActive ? 'text-white translate-x-0.5' : 'text-slate-300 dark:text-slate-600 group-hover:translate-x-0.5'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Official NAAC Portal External Link */}
      <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
        <a
          href="https://www.naac.gov.in/"
          target="_blank"
          rel="noopener noreferrer"
          className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold transition-all group"
        >
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>NAAC Portal</span>
          </div>
          <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-600" />
        </a>

        <div className="px-2 py-1.5 text-[10px] text-slate-400 dark:text-slate-500 text-center leading-relaxed">
          Independent Educational Assistant. Not an official branch of NAAC.
        </div>
      </div>
    </aside>
  );
};
