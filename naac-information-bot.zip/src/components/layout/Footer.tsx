import React from 'react';
import { ShieldAlert, ExternalLink, GraduationCap, Heart, HelpCircle, FileText } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Footer: React.FC = () => {
  const { setActiveTab } = useApp();

  return (
    <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs py-8 transition-colors mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand & Purpose */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="font-extrabold text-slate-900 dark:text-white text-base">
                NAAC Information Bot
              </span>
            </div>
            <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-xs max-w-md">
              An intelligent, retrieval-augmented educational assistant designed to demystify NAAC accreditation, criteria requirements, institutional documentation, and IQAC quality assurance for higher education institutions in India.
            </p>
            {/* Disclaimer box */}
            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 flex items-start gap-2.5 max-w-lg">
              <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <p className="text-[11px] text-amber-900 dark:text-amber-200 leading-normal">
                <strong>Statutory Disclaimer:</strong> This application is an independent educational and institutional productivity assistant. It is not affiliated with, endorsed by, or representing the National Assessment and Accreditation Council (NAAC) or UGC. HEIs must always verify official manuals and circulars on{' '}
                <a
                  href="https://www.naac.gov.in"
                  target="_blank"
                  rel="noreferrer"
                  className="underline font-semibold hover:text-amber-700 dark:hover:text-amber-100"
                >
                  www.naac.gov.in
                </a>.
              </p>
            </div>
          </div>

          {/* Quick Features */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
              Explore Modules
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button
                  onClick={() => setActiveTab('chat')}
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>Ask NAAC AI Assistant</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('criteria')}
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>7 Assessment Criteria Explorer</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('documents')}
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>Document Evidence Guide</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('process')}
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>Accreditation Journey Tracker</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('faq')}
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>NAAC FAQ & Common Doubts</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Official Portals */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
              Official Portals
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <a
                  href="https://www.naac.gov.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>NAAC Official Website</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://assessmentonline.naac.gov.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>HEI Assessment Portal (A&A)</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://www.ugc.gov.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>University Grants Commission (UGC)</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://aishe.gov.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-teal-600 dark:hover:text-teal-400 transition-colors flex items-center gap-1.5"
                >
                  <span>AISHE Higher Education Portal</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-200 dark:border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} NAAC Information Bot. Developed for educational excellence.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <span>Supports English, हिन्दी, and मराठी</span>
            </span>
            <span>•</span>
            <span>Built with Gemini AI & Modern Full-Stack</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
