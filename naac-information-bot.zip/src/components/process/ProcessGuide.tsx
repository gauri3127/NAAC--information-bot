import React, { useState, useEffect } from 'react';
import {
  GitFork,
  CheckCircle2,
  Circle,
  Clock,
  FileText,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Bot,
  Sparkles,
  ShieldCheck,
  Check,
  ArrowRight
} from 'lucide-react';
import { api } from '../../services/api';
import { AccreditationStage } from '../../types';
import { useApp } from '../../context/AppContext';

export const ProcessGuide: React.FC = () => {
  const { startChatWithQuery, showToast } = useApp();
  const [stages, setStages] = useState<AccreditationStage[]>([]);
  const [activeStageId, setActiveStageId] = useState<number>(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStages();
  }, []);

  const loadStages = async () => {
    try {
      setLoading(true);
      const data = await api.getStages();
      setStages(data);
    } catch {
      showToast('Failed to load stages', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStage = async (stageId: number, e?: React.MouseEvent) => {
    e?.stopPropagation();
    try {
      const updated = await api.toggleStage(stageId);
      setStages(prev => prev.map(s => (s.id === stageId ? updated : s)));
      showToast(`Stage ${stageId} status updated!`, 'success');
    } catch {
      showToast('Failed to update stage status', 'error');
    }
  };

  const activeStage = stages.find(s => s.id === activeStageId) || stages[0];
  const completedStagesCount = stages.filter(s => s.completed).length;
  const progressPercent = stages.length > 0 ? Math.round((completedStagesCount / stages.length) * 100) : 0;

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 to-teal-950 rounded-2xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-semibold mb-3 border border-teal-500/30">
            <GitFork className="w-4 h-4" />
            <span>Institutional Accreditation Roadmap</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            NAAC Accreditation Process: Step-by-Step Guide
          </h1>
          <p className="mt-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
            Navigate the complete institutional accreditation lifecycle from initial IIQA registration to Self Study Report (SSR), DVV validation, Peer Team Visit, and post-accreditation AQARs.
          </p>

          {/* Progress Tracker Strip */}
          <div className="mt-6 p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-semibold text-slate-200">
                Institutional Journey Completion: {completedStagesCount} of {stages.length} Stages Completed
              </span>
              <span className="font-bold text-teal-400">{progressPercent}%</span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
              <div
                className="bg-teal-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Process Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Stage List */}
        <div className="lg:col-span-5 space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 pb-1">
            8 Sequential Assessment Milestones
          </h3>

          {stages.map((stage) => {
            const isActive = stage.id === activeStageId;
            return (
              <div
                key={stage.id}
                onClick={() => setActiveStageId(stage.id)}
                className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                  isActive
                    ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-500 text-teal-950 dark:text-teal-100 shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  {/* Stage completion indicator button */}
                  <button
                    onClick={(e) => handleToggleStage(stage.id, e)}
                    className="mt-0.5 shrink-0 text-slate-400 hover:text-teal-600 transition-colors"
                    title={stage.completed ? 'Mark as Incomplete' : 'Mark as Completed'}
                  >
                    {stage.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-100 dark:fill-emerald-950" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                    )}
                  </button>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.2 rounded-sm bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300">
                        Step {stage.stepNumber}
                      </span>
                      <span className="text-[10px] text-slate-400 flex items-center gap-1 font-medium">
                        <Clock className="w-3 h-3" />
                        {stage.estimatedTimeline}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-slate-900 dark:text-white mt-1 leading-snug">
                      {stage.title}
                    </h4>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                      {stage.shortDescription}
                    </p>
                  </div>
                </div>

                <ChevronRight
                  className={`w-4 h-4 shrink-0 transition-transform ${
                    isActive ? 'text-teal-600 translate-x-1' : 'text-slate-300 dark:text-slate-600'
                  }`}
                />
              </div>
            );
          })}
        </div>

        {/* Right Column: Detailed Stage Guidance */}
        {activeStage && (
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300 uppercase tracking-wider">
                      Stage {activeStage.stepNumber} of 8
                    </span>
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-teal-600" />
                      {activeStage.estimatedTimeline}
                    </span>
                  </div>
                  <h2 className="text-xl font-extrabold text-slate-900 dark:text-white mt-2">
                    {activeStage.title}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    {activeStage.shortDescription}
                  </p>
                </div>

                {/* Mark as completed / Ask AI buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleToggleStage(activeStage.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-2xs ${
                      activeStage.completed
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{activeStage.completed ? 'Completed' : 'Mark as Done'}</span>
                  </button>

                  <button
                    onClick={() =>
                      startChatWithQuery(
                        `Explain Stage ${activeStage.stepNumber}: ${activeStage.title} of the NAAC accreditation process in detail. What are the best practices, timelines, and pitfalls to avoid?`
                      )
                    }
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors shadow-xs"
                  >
                    <Bot className="w-3.5 h-3.5" />
                    <span>Ask AI</span>
                  </button>
                </div>
              </div>

              {/* Step by Step Breakdown */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Operational Guidelines & Action Steps
                </h4>
                <div className="space-y-2.5">
                  {activeStage.detailedGuidance.map((step, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 flex items-start gap-3 leading-relaxed"
                    >
                      <span className="w-5 h-5 rounded-full bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300 font-bold flex items-center justify-center shrink-0 text-[11px]">
                        {idx + 1}
                      </span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Critical Documents Required */}
              <div className="p-4 rounded-xl border border-teal-100 dark:border-teal-900/40 bg-teal-50/50 dark:bg-teal-950/20 space-y-2">
                <h4 className="text-xs font-bold text-teal-900 dark:text-teal-200 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-teal-600" />
                  <span>Critical Enclosures & Documents for Stage {activeStage.stepNumber}</span>
                </h4>
                <ul className="space-y-1.5 pl-6 list-disc text-xs text-slate-700 dark:text-slate-300">
                  {activeStage.criticalDocuments.map((doc, i) => (
                    <li key={i}>{doc}</li>
                  ))}
                </ul>
              </div>

              {/* Do's and Don'ts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Do's */}
                <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/40 dark:bg-emerald-950/20 space-y-2">
                  <h4 className="text-xs font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Recommended Do's</span>
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                    {activeStage.dosAndDonts.dos.map((item, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-emerald-600 font-bold">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Don'ts */}
                <div className="p-4 rounded-xl border border-rose-200 dark:border-rose-900/40 bg-rose-50/40 dark:bg-rose-950/20 space-y-2">
                  <h4 className="text-xs font-bold text-rose-900 dark:text-rose-300 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-rose-600" />
                    <span>Critical Pitfalls & Don'ts</span>
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                    {activeStage.dosAndDonts.donts.map((item, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-rose-600 font-bold">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Official Link */}
              {activeStage.officialLink && (
                <div className="pt-2 flex items-center justify-between text-xs text-slate-500">
                  <span>Portal Action Link:</span>
                  <a
                    href={activeStage.officialLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 font-semibold text-teal-600 hover:text-teal-700 dark:text-teal-400"
                  >
                    <span>Proceed to Official NAAC Portal</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
