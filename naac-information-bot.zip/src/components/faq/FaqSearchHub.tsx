import React, { useState, useEffect, useMemo } from 'react';
import {
  HelpCircle,
  Search,
  Bot,
  ChevronDown,
  ChevronUp,
  Tag,
  History,
  X,
  Sparkles,
  ArrowRight,
  BookOpen
} from 'lucide-react';
import { api } from '../../services/api';
import { FAQItem } from '../../types';
import { useApp } from '../../context/AppContext';

export const FaqSearchHub: React.FC = () => {
  const { startChatWithQuery } = useApp();
  const [faqs, setFaqs] = useState<FAQItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>(null);

  // Search History in LocalStorage
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('naac_search_history') || '[]');
    } catch {
      return [];
    }
  });

  useEffect(() => {
    loadFaqs();
  }, []);

  const loadFaqs = async () => {
    try {
      const data = await api.getFaqs();
      setFaqs(data);
    } catch (err) {
      console.error('Failed to load FAQs', err);
    }
  };

  const categories = [
    'All',
    'NAAC Basics',
    'Accreditation Process',
    'IQAC',
    'Assessment Criteria',
    'Documentation',
    'Quality Assurance',
    'Grading & Outcomes',
    'Accreditation Updates'
  ];

  const handleSearchSubmit = (queryText: string) => {
    const text = queryText.trim();
    if (!text) return;
    setSearchQuery(text);
    if (!searchHistory.includes(text)) {
      const updated = [text, ...searchHistory.slice(0, 5)];
      setSearchHistory(updated);
      localStorage.setItem('naac_search_history', JSON.stringify(updated));
    }
  };

  const removeSearchHistoryItem = (item: string) => {
    const updated = searchHistory.filter(h => h !== item);
    setSearchHistory(updated);
    localStorage.setItem('naac_search_history', JSON.stringify(updated));
  };

  const clearAllSearchHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem('naac_search_history');
  };

  const toggleExpand = (id: string) => {
    setExpandedFaqId(prev => (prev === id ? null : id));
  };

  const filteredFaqs = useMemo(() => {
    return faqs.filter(f => {
      const matchCat = selectedCategory === 'All' || f.category === selectedCategory;
      const q = searchQuery.toLowerCase();
      const matchQuery =
        !searchQuery.trim() ||
        f.question.toLowerCase().includes(q) ||
        f.answer.toLowerCase().includes(q) ||
        f.tags.some(t => t.toLowerCase().includes(q));
      return matchCat && matchQuery;
    });
  }, [faqs, selectedCategory, searchQuery]);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Banner */}
      <div className="text-center space-y-3 py-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-xs font-bold border border-teal-200 dark:border-teal-800/60">
          <HelpCircle className="w-3.5 h-3.5 text-teal-600" />
          <span>Knowledge & FAQ Hub</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Frequently Asked Questions & Answers
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
          Find authoritative answers to common institutional queries regarding NAAC criteria, DVV requirements, SSR drafting, and IQAC operations.
        </p>
      </div>

      {/* Global Search Bar */}
      <div className="relative max-w-2xl mx-auto">
        <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSearchSubmit(searchQuery);
          }}
          placeholder="Type keywords: IQAC role, SSR vs AQAR, DVV clarification, SSS survey..."
          className="w-full pl-11 pr-24 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-teal-500 shadow-md shadow-slate-100 dark:shadow-none"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-12 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
        <button
          onClick={() => handleSearchSubmit(searchQuery)}
          className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs"
        >
          Search
        </button>
      </div>

      {/* Search History Chips */}
      {searchHistory.length > 0 && (
        <div className="flex items-center justify-center gap-2 flex-wrap text-xs text-slate-500">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-400">
            <History className="w-3 h-3" />
            <span>Recent:</span>
          </div>
          {searchHistory.map((item, idx) => (
            <span
              key={idx}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] cursor-pointer hover:bg-slate-200"
              onClick={() => setSearchQuery(item)}
            >
              <span>{item}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeSearchHistoryItem(item);
                }}
                className="hover:text-rose-500"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
          <button
            onClick={clearAllSearchHistory}
            className="text-[10px] text-slate-400 hover:text-rose-500 underline ml-1"
          >
            Clear
          </button>
        </div>
      )}

      {/* Category Filter Pills */}
      <div className="flex items-center justify-center gap-1.5 flex-wrap pt-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              selectedCategory === cat
                ? 'bg-teal-700 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* FAQ Accordion List */}
      <div className="space-y-3 pt-2">
        {filteredFaqs.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
            <HelpCircle className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
              No matching questions found in this category
            </p>
            <button
              onClick={() => startChatWithQuery(searchQuery || 'What are the main requirements of NAAC?')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors"
            >
              <Bot className="w-4 h-4" />
              <span>Ask NAAC AI Assistant directly</span>
            </button>
          </div>
        ) : (
          filteredFaqs.map((faq) => {
            const isExpanded = expandedFaqId === faq.id;
            return (
              <div
                key={faq.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xs transition-all hover:border-slate-300 dark:hover:border-slate-700"
              >
                <button
                  onClick={() => toggleExpand(faq.id)}
                  className="w-full text-left p-4 sm:p-5 flex items-start justify-between gap-4"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
                      {faq.category}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                      {faq.question}
                    </h3>
                  </div>

                  <div className="shrink-0 p-1 text-slate-400">
                    {isExpanded ? <ChevronUp className="w-5 h-5 text-teal-600" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-4 animate-in fade-in">
                    <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                      {faq.answer}
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      {/* Tags */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <Tag className="w-3 h-3 text-slate-400" />
                        {faq.tags.map((t, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500"
                          >
                            #{t}
                          </span>
                        ))}
                      </div>

                      {/* Ask AI follow-up */}
                      <button
                        onClick={() =>
                          startChatWithQuery(
                            `Regarding this question: "${faq.question}", could you provide more practical examples and evidence requirements?`
                          )
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/50 hover:bg-teal-100 text-teal-800 dark:text-teal-300 font-bold text-xs transition-colors border border-teal-200 dark:border-teal-800/60"
                      >
                        <Bot className="w-3.5 h-3.5 text-teal-600" />
                        <span>Ask AI follow-up</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
