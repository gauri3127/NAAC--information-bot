import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  BarChart3,
  Users,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  Bell,
  Plus,
  Trash2,
  FileCheck,
  CheckCircle2,
  Globe,
  ExternalLink,
  Lock
} from 'lucide-react';
import { api } from '../../services/api';
import { AdminStats, Announcement } from '../../types';
import { useApp } from '../../context/AppContext';

export const AdminDashboard: React.FC = () => {
  const { currentUser, showToast } = useApp();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  // Announcement Form
  const [annTitle, setAnnTitle] = useState('');
  const [annSummary, setAnnSummary] = useState('');
  const [annLink, setAnnLink] = useState('https://www.naac.gov.in/');
  const [annBadge, setAnnBadge] = useState<'Notice' | 'Manual Update' | 'Advisory' | 'Framework'>('Notice');
  const [isAddingAnn, setIsAddingAnn] = useState(false);

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    try {
      setLoading(true);
      const [statsData, annData] = await Promise.all([
        api.getAdminStats(),
        api.getAnnouncements()
      ]);
      setStats(statsData);
      setAnnouncements(annData);
    } catch {
      showToast('Failed to load administrative analytics', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annSummary.trim()) return;

    try {
      const created = await api.createAnnouncement({
        title: annTitle,
        summary: annSummary,
        link: annLink,
        badge: annBadge
      });
      setAnnouncements(prev => [created, ...prev]);
      setAnnTitle('');
      setAnnSummary('');
      setIsAddingAnn(false);
      showToast('Official notice published successfully', 'success');
    } catch {
      showToast('Failed to create announcement', 'error');
    }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    if (!window.confirm('Delete this notice?')) return;
    try {
      await api.deleteAnnouncement(id);
      setAnnouncements(prev => prev.filter(a => a.id !== id));
      showToast('Notice deleted', 'info');
    } catch {
      showToast('Failed to delete notice', 'error');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-slate-900 dark:text-white">
                NAAC Administration & Analytics
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Monitor institutional query engagement, publish official advisories, and track document completion
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5" />
            Admin Role Authorized
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Total AI Consultations</span>
              <MessageSquare className="w-4 h-4 text-teal-600" />
            </div>
            <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {stats.totalQueries}
            </p>
            <p className="text-[11px] text-teal-600 font-medium mt-1">
              Gemini 3.8 Grounded Answers
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Answer Helpfulness Rate</span>
              <ThumbsUp className="w-4 h-4 text-emerald-600" />
            </div>
            <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
              {stats.totalQueries > 0
                ? `${Math.round((stats.helpfulCount / (stats.helpfulCount + stats.unhelpfulCount || 1)) * 100)}%`
                : '96%'}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              {stats.helpfulCount} helpful vs {stats.unhelpfulCount} unhelpful
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Evidence Documents</span>
              <FileCheck className="w-4 h-4 text-teal-600" />
            </div>
            <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {stats.completedDocuments} / {stats.totalDocuments}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              {Math.round((stats.completedDocuments / (stats.totalDocuments || 1)) * 100)}% institutional files ready
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Language Distribution</span>
              <Globe className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                EN: {stats.languageDistribution.en}
              </span>
              <span>•</span>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                HI: {stats.languageDistribution.hi}
              </span>
              <span>•</span>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                MR: {stats.languageDistribution.mr}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">Multilingual support active</p>
          </div>
        </div>
      )}

      {/* Announcements Manager & Recent Queries Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Manage Announcements */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Official NAAC Notices & Framework Advisories
              </h3>
            </div>
            <button
              onClick={() => setIsAddingAnn(prev => !prev)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAddingAnn ? 'Close' : 'Publish Notice'}</span>
            </button>
          </div>

          {/* Add Notice Form */}
          {isAddingAnn && (
            <form onSubmit={handleCreateAnnouncement} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3 text-xs animate-in fade-in">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Notice Title *
                </label>
                <input
                  type="text"
                  required
                  value={annTitle}
                  onChange={(e) => setAnnTitle(e.target.value)}
                  placeholder="e.g. Radhakrishnan Committee Reform Advisory"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Summary / Details *
                </label>
                <textarea
                  required
                  rows={2}
                  value={annSummary}
                  onChange={(e) => setAnnSummary(e.target.value)}
                  placeholder="Summary of the notice, circular or RAF update..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:border-teal-500 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Badge Type
                  </label>
                  <select
                    value={annBadge}
                    onChange={(e) => setAnnBadge(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  >
                    <option value="Notice">Notice</option>
                    <option value="Framework">Framework</option>
                    <option value="Advisory">Advisory</option>
                    <option value="Manual Update">Manual Update</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Official Reference Link
                  </label>
                  <input
                    type="url"
                    value={annLink}
                    onChange={(e) => setAnnLink(e.target.value)}
                    placeholder="https://www.naac.gov.in"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg transition-colors"
              >
                Publish Notice to Dashboard
              </button>
            </form>
          )}

          {/* List of active notices */}
          <div className="space-y-3">
            {announcements.map((ann) => (
              <div
                key={ann.id}
                className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-start justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300">
                      {ann.badge}
                    </span>
                    <span className="text-[10px] text-slate-400">{ann.date}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {ann.title}
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {ann.summary}
                  </p>
                </div>

                <button
                  onClick={() => handleDeleteAnnouncement(ann.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors shrink-0"
                  title="Delete notice"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Recent Query Activity Logs */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-teal-600" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Live Query Consultation Feed
              </h3>
            </div>
            <span className="text-[10px] text-slate-400">Anonymized for Privacy</span>
          </div>

          <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
            {stats?.recentQueries.map((q, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 text-xs flex items-start justify-between gap-3"
              >
                <div className="space-y-0.5">
                  <p className="font-semibold text-slate-800 dark:text-slate-200 leading-snug">
                    "{q.query}"
                  </p>
                  <p className="text-[10px] text-slate-400">
                    {new Date(q.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • Language: {q.language.toUpperCase()}
                  </p>
                </div>

                {q.hasFeedback && (
                  <span className="shrink-0 p-1 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 text-[10px] font-bold">
                    Feedback Logged
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
