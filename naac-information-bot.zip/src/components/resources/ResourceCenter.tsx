import React, { useState, useEffect, useMemo } from 'react';
import {
  BookOpen,
  Search,
  ExternalLink,
  ShieldCheck,
  Bookmark,
  BookmarkCheck,
  Filter,
  FileText,
  Calendar,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { api } from '../../services/api';
import { OfficialResource } from '../../types';
import { useApp } from '../../context/AppContext';

export const ResourceCenter: React.FC = () => {
  const { showToast, startChatWithQuery } = useApp();
  const [resources, setResources] = useState<OfficialResource[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('naac_bookmarks') || '[]');
    } catch {
      return [];
    }
  });

  useEffect(() => {
    loadResources();
  }, []);

  const loadResources = async () => {
    try {
      const data = await api.getResources();
      setResources(data);
    } catch {
      showToast('Failed to load official resources', 'error');
    }
  };

  const toggleBookmark = (id: string) => {
    let updated: string[];
    if (bookmarkedIds.includes(id)) {
      updated = bookmarkedIds.filter(i => i !== id);
      showToast('Removed from bookmarked resources', 'info');
    } else {
      updated = [...bookmarkedIds, id];
      showToast('Saved to your bookmarks', 'success');
    }
    setBookmarkedIds(updated);
    localStorage.setItem('naac_bookmarks', JSON.stringify(updated));
  };

  const categories = ['All', 'Manual', 'Guideline', 'Circular', 'Format', 'Portal'];

  const filteredResources = useMemo(() => {
    return resources.filter((res) => {
      const matchCat = selectedCategory === 'All' || res.category === selectedCategory;
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !searchQuery.trim() ||
        res.title.toLowerCase().includes(q) ||
        res.description.toLowerCase().includes(q) ||
        res.category.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [resources, selectedCategory, searchQuery]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
                <BookOpen className="w-5 h-5" />
              </div>
              <h1 className="text-xl font-extrabold text-slate-900 dark:text-white">
                Official NAAC & Higher Education Resource Center
              </h1>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Curated, verified links to official NAAC assessment manuals, standard operating procedures (SOP), data templates, and regulatory circulars.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500">
              {bookmarkedIds.length} Saved Bookmarks
            </span>
          </div>
        </div>

        {/* Advisory banner */}
        <div className="mt-4 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <span>
            <strong>Authenticity Guarantee:</strong> All resource links point directly to official government / NAAC domains (<code>naac.gov.in</code>, <code>ugc.gov.in</code>, <code>aishe.gov.in</code>). Publication and verification dates are explicitly displayed.
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search manuals, SOPs, guidelines..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-teal-500 shadow-2xs"
          />
        </div>
      </div>

      {/* Resource Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredResources.map((res) => {
          const isBookmarked = bookmarkedIds.includes(res.id);
          return (
            <div
              key={res.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between hover:border-teal-400 dark:hover:border-teal-600 transition-all group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/50 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800/60">
                    {res.category}
                  </span>

                  <button
                    onClick={() => toggleBookmark(res.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 transition-colors"
                    title={isBookmarked ? 'Remove Bookmark' : 'Bookmark this Resource'}
                  >
                    {isBookmarked ? (
                      <BookmarkCheck className="w-4 h-4 text-teal-600 fill-teal-100 dark:fill-teal-950" />
                    ) : (
                      <Bookmark className="w-4 h-4" />
                    )}
                  </button>
                </div>

                <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-300 transition-colors leading-snug">
                  {res.title}
                </h3>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-3">
                  {res.description}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {res.publicationDate}
                  </span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Verified: {res.lastVerifiedDate}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={res.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs transition-colors shadow-2xs"
                  >
                    <span>Open Official Resource</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>

                  <button
                    onClick={() =>
                      startChatWithQuery(
                        `Explain the key contents and significance of the official resource: "${res.title}". What should an institution focus on?`
                      )
                    }
                    className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="Ask AI about this document"
                  >
                    <Sparkles className="w-4 h-4 text-teal-600" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
