import { NaacCriterion, AccreditationStage, OfficialResource, FAQItem, DocumentItem, Announcement } from '../types';

export const NAAC_CRITERIA_DATA: NaacCriterion[] = [
  {
    id: 1,
    number: 'Criterion I',
    title: 'Curricular Aspects',
    titleHi: 'पाठ्यचर्या पहलू (Curricular Aspects)',
    titleMr: 'अभ्यासक्रम पैलू (Curricular Aspects)',
    shortDescription: 'Focuses on curriculum design, development, academic flexibility, curriculum enrichment, and stakeholder feedback systems.',
    detailedOverview: 'Criterion 1 assesses how an institution aligns its curriculum with its vision and the emerging regional, national, and global needs. For affiliated colleges, it examines operational implementation of the affiliating university curriculum, academic calendar, program electives/add-on courses, and systematic structured feedback from students, teachers, employers, and alumni.',
    weightageAffiliatedUG: 100,
    weightageAffiliatedPG: 100,
    weightageAutonomous: 150,
    weightageUniversity: 150,
    keyIndicators: [
      {
        code: '1.1',
        name: 'Curricular Planning and Implementation',
        description: 'Systematic planning, adherence to academic calendar, lesson plans, course files, and curriculum delivery mechanisms.',
        coreDocuments: ['Institutional Academic Calendar', 'Teaching Plans and Log Books', 'Minutes of Curriculum/Department Meetings', 'CIE (Continuous Internal Evaluation) schedules']
      },
      {
        code: '1.2',
        name: 'Academic Flexibility',
        description: 'Choice Based Credit System (CBCS), elective options, interdisciplinary programs, Certificate and Value-Added courses offering transferable skills.',
        coreDocuments: ['List of Value-Added / Add-on courses (>30 contact hours)', 'Student enrollment & attendance in certificate courses', 'CBCS/Elective notification from affiliating University', 'Course completion certificates']
      },
      {
        code: '1.3',
        name: 'Curriculum Enrichment',
        description: 'Integration of cross-cutting issues (Professional Ethics, Gender, Human Values, Environment and Sustainability) into curriculum, experiential learning (field trips, internships, projects).',
        coreDocuments: ['Syllabus mapping of courses integrating cross-cutting themes', 'Internship completion letters with student details', 'Field project reports and student lists', 'Project work submission registers']
      },
      {
        code: '1.4',
        name: 'Feedback System',
        description: 'Structured feedback on syllabus design and review from (1) Students, (2) Teachers, (3) Employers, and (4) Alumni, along with Action Taken Report (ATR) published on website.',
        coreDocuments: ['Feedback questionnaires for all 4 stakeholder groups', 'Stakeholder feedback analysis reports', 'Action Taken Reports (ATR) approved by Academic Council/IQAC', 'Website URL hosting feedback analysis and ATR']
      }
    ],
    typicalEvidence: [
      'Documented Academic Calendar aligned with affiliating university timeline',
      'Value-added/certificate course brochures, syllabus, student roll lists, and completion certificates',
      'Undertaking and completion certificates for student internships and field projects',
      'Stakeholder feedback survey forms, tabulated data, graphical analysis, and IQAC Action Taken Reports',
      'Minutes of Board of Studies (BoS) or Academic Advisory meetings'
    ],
    preparationChecklist: [
      'Ensure Academic Calendar is published before the semester starts and uploaded on the college website',
      'Verify certificate/add-on courses have minimum 30 contact hours with verifiable syllabus and assessment tests',
      'Maintain 100% geo-tagged proof and student lists for field visits/internships',
      'Collect feedback across all 4 stakeholders: Students, Teachers, Employers, and Alumni',
      'Publish ATR (Action Taken Report) prominently on the college website for public viewing'
    ],
    faqs: [
      {
        question: 'Are all 4 stakeholder feedback categories mandatory for affiliated colleges?',
        answer: 'Yes. NAAC metric 1.4 requires structured feedback from Students, Teachers, Employers, and Alumni. Lack of employer or alumni feedback often leads to metric score reductions during DVV.'
      },
      {
        question: 'What is the minimum duration required for Value-Added Courses in Criterion 1?',
        answer: 'Typically, NAAC guidelines specify a minimum of 30 contact hours or equivalent credits for value-added / certificate courses to qualify for metric 1.2.2.'
      }
    ],
    manualReferences: [
      {
        title: 'NAAC RAF Manual - Criterion 1 Guidelines',
        url: 'https://www.naac.gov.in/',
        note: 'Refer to latest manual for metric weightages based on your institution category (Affiliated/Autonomous/University).'
      }
    ]
  },
  {
    id: 2,
    number: 'Criterion II',
    title: 'Teaching-Learning and Evaluation',
    titleHi: 'शिक्षण-अधिगम और मूल्यांकन (Teaching-Learning & Evaluation)',
    titleMr: 'अध्यापन-अध्ययन आणि मूल्यमापन (Teaching-Learning & Evaluation)',
    shortDescription: 'Focuses on student enrollment, diversity, student-centric methods, teacher profile & qualifications, evaluation processes, learning outcomes (COs/POs), and Student Satisfaction Survey.',
    detailedOverview: 'Criterion 2 carries the highest weightage (350 marks for affiliated colleges). It evaluates teacher quality, pedagogical innovations, continuous internal evaluation (CIE), student mentoring, attainment of Course Outcomes (COs) and Program Outcomes (POs), and the centralized online Student Satisfaction Survey (SSS) conducted directly by NAAC.',
    weightageAffiliatedUG: 350,
    weightageAffiliatedPG: 350,
    weightageAutonomous: 300,
    weightageUniversity: 200,
    keyIndicators: [
      {
        code: '2.1',
        name: 'Student Enrollment and Profile',
        description: 'Demand ratio, average enrollment percentage against sanctioned intake, reservation quota adherence (SC/ST/OBC/Divyangjan).',
        coreDocuments: ['Sanctioned seat letters from competent authority/State Govt', 'Admission roster verified by competent authority', 'Category-wise admitted students roll lists']
      },
      {
        code: '2.2',
        name: 'Student Diversity & Teacher-Student Ratio',
        description: 'Full-time teacher-to-student ratio, special programs for advanced learners and slow learners.',
        coreDocuments: ['Full-time teacher appointment orders & sanction letters', 'Mentor-mentee allocation registers & meeting records', 'Diagnostic test results & remedial coaching logs']
      },
      {
        code: '2.3',
        name: 'Teaching-Learning Process',
        description: 'Student-centric methods: experiential, participative, problem-solving methodologies, ICT-enabled tools, LMS usage.',
        coreDocuments: ['ICT-enabled classroom & smart board geo-tagged photos', 'LMS portal logs & e-content created by teachers', 'Experimental learning logs, simulation labs, workshops']
      },
      {
        code: '2.4',
        name: 'Teacher Profile and Quality',
        description: 'Full-time teachers with Ph.D./NET/SET, teaching experience in the same institution, awards & recognition.',
        coreDocuments: ['Ph.D. degree certificates & NET/SET qualifying letters', 'Service books / appointment letters confirming full-time tenure', 'Faculty awards and national/international fellowships']
      },
      {
        code: '2.5',
        name: 'Evaluation Process and Reforms',
        description: 'Internal evaluation transparency, robustness, time-bound grievance redressal mechanism regarding marks.',
        coreDocuments: ['Continuous Internal Evaluation (CIE) manual/circulars', 'Internal exam question papers and evaluation sample rubrics', 'Minutes of Examination Grievance Redressal Committee']
      },
      {
        code: '2.6',
        name: 'Student Performance and Learning Outcomes',
        description: 'Stated Program Outcomes (POs) and Course Outcomes (COs), attainment measurement methodology, final year pass percentage.',
        coreDocuments: ['Defined POs, PSOs, and COs displayed on website', 'Direct & indirect CO-PO attainment calculation sheets', 'Final year university results & certified pass percentages']
      },
      {
        code: '2.7',
        name: 'Student Satisfaction Survey (SSS)',
        description: 'Online survey administered directly by NAAC to enrolled students assessing institutional teaching-learning effectiveness.',
        coreDocuments: ['Clean, verified student database with mobile numbers & emails', 'Institution-level internal SSS pilot reports']
      }
    ],
    typicalEvidence: [
      'Government/University sanctioned intake letters and state reservation roster',
      'List of full-time teachers appointed against sanctioned posts signed by Principal',
      'Documented CO-PO attainment methodology with course-level sample spreadsheets',
      'Certified consolidated result sheet signed by the Controller of Examinations',
      'Mentor-mentee diary with documented counselling sessions and outcomes'
    ],
    preparationChecklist: [
      'Ensure Student-Teacher ratio is optimal (ideally 1:15 to 1:20) and documented properly',
      'Verify that all full-time teachers are appointed for a full academic year and not purely ad-hoc hourly',
      'Display POs, PSOs, and COs clearly on the institutional website and course files',
      'Keep student mobile numbers and email IDs strictly updated for the NAAC SSS portal',
      'Maintain an active Examination Grievance Redressal register with logged resolutions'
    ],
    faqs: [
      {
        question: 'Who conducts the Student Satisfaction Survey (SSS) in NAAC?',
        answer: 'NAAC centrally conducts the SSS by emailing/messaging a randomly sampled percentage of students using the student database submitted by the college during SSR submission.'
      },
      {
        question: 'What is the definition of a full-time teacher in NAAC?',
        answer: 'A teacher employed for at least 90% of the normal working hours of the institution for a full academic year, paid regular salary against a sanctioned post.'
      }
    ],
    manualReferences: [
      {
        title: 'NAAC Standard Operating Procedure for Teaching-Learning (Criterion 2)',
        url: 'https://www.naac.gov.in/',
        note: 'Crucial for understanding DVV data templates for faculty and student enrollment.'
      }
    ]
  },
  {
    id: 3,
    number: 'Criterion III',
    title: 'Research, Innovations and Extension',
    titleHi: 'अनुसंधान, नवाचार और विस्तार (Research, Innovations & Extension)',
    titleMr: 'संशोधन, नवोपक्रम आणि विस्तार (Research, Innovations & Extension)',
    shortDescription: 'Focuses on research facilities, seed grants, research mobilization, intellectual property, research publications in UGC-CARE, extension activities (NSS/NCC), and collaborative MoUs.',
    detailedOverview: 'Criterion 3 evaluates institutional research culture, incubation/start-up ecosystems, faculty research publications, books, book chapters, community outreach/extension projects (NSS, NCC, YRC), awards received for extension, and functional industry-academia collaborations or MoUs.',
    weightageAffiliatedUG: 110,
    weightageAffiliatedPG: 120,
    weightageAutonomous: 150,
    weightageUniversity: 250,
    keyIndicators: [
      {
        code: '3.1',
        name: 'Resource Mobilization for Research',
        description: 'Grants received from government and non-government agencies for research projects, seed money provided by the institution to teachers.',
        coreDocuments: ['Sanction letters of research grants from UGC/DST/ICSSR/DBT/Industry', 'Institutional policy and ledger entries for teacher seed money', 'Audited utilization certificates of research grants']
      },
      {
        code: '3.2',
        name: 'Innovation Ecosystem',
        description: 'Ecosystem for innovations, Incubation centre, Entrepreneurship Development Cell (EDC), IPR workshops, start-up initiatives.',
        coreDocuments: ['Incubation centre notification & facility photos', 'Reports on IPR, Industry-Academia, Research Methodology workshops', 'List of start-ups incubated on campus']
      },
      {
        code: '3.3',
        name: 'Research Publications and Awards',
        description: 'Research papers published in UGC-CARE listed journals / Scopus / Web of Science, books, chapters in edited volumes, conference proceedings.',
        coreDocuments: ['List of papers with UGC-CARE group links, ISSN, and impact factors', 'First page and cover page copies of books/chapters with ISBN', 'Citation index and h-index reports (where applicable)']
      },
      {
        code: '3.4',
        name: 'Extension Activities',
        description: 'Community development extension activities conducted through NSS, NCC, Red Cross, neighbourhood outreach, awards & recognitions received.',
        coreDocuments: ['NSS/NCC annual reports & geo-tagged event photographs', 'Attendance sheets of participating students signed by coordinator', 'Appreciation letters and awards from Gram Panchayats / NGOs / Govt']
      },
      {
        code: '3.5',
        name: 'Collaboration & MoUs',
        description: 'Collaborative activities for research, faculty exchange, student internship, and functional MoUs with industry and academic bodies.',
        coreDocuments: ['Copies of signed MoUs with active institutions/industries', 'Reports of activities conducted under each MoU with date & outcomes', 'Student internship/training completion letters generated via MoUs']
      }
    ],
    typicalEvidence: [
      'Grant sanction letters along with audited statements of research accounts',
      'Copies of UGC-CARE journal papers with clear author institutional affiliation',
      'NSS / NCC activity reports with geo-tagged photos, date stamps, and participant lists',
      'MoU documents on legal stamp paper with documented activity reports'
    ],
    preparationChecklist: [
      'Verify every research publication is indexed in UGC-CARE List Group I or II or Scopus',
      'Ensure institutional affiliation is accurately printed in published papers',
      'Sign active MoUs that show actual collaborative events (mere paper MoUs get zero score in DVV)',
      'Organize IPR (Intellectual Property Rights) seminars annually with complete documentation',
      'Ensure NSS/NCC activities have clear local community participation records'
    ],
    faqs: [
      {
        question: 'Does NAAC accept papers published in non-UGC-CARE journals?',
        answer: 'For Metric 3.3.1, NAAC strictly validates papers against the UGC-CARE list (including Scopus and Web of Science). Papers in predatory or unlisted journals are disqualified during DVV.'
      },
      {
        question: 'What qualifies an MoU as "functional" in NAAC assessment?',
        answer: 'An MoU is considered functional only if tangible collaborative activities (such as student training, joint research, guest lectures, or internships) took place during the assessment period with documented evidence.'
      }
    ],
    manualReferences: [
      {
        title: 'UGC-CARE Journal Guidelines & NAAC DVV Clarifications',
        url: 'https://www.naac.gov.in/',
        note: 'Check the DVV SOP for metric-specific publication verification protocols.'
      }
    ]
  },
  {
    id: 4,
    number: 'Criterion IV',
    title: 'Infrastructure and Learning Resources',
    titleHi: 'बुनियादी ढांचा और शिक्षण संसाधन (Infrastructure & Resources)',
    titleMr: 'पायाभूत सुविधा आणि अध्ययन संसाधने (Infrastructure & Resources)',
    shortDescription: 'Focuses on physical facilities, classrooms, laboratories, sports/cultural amenities, library automation (ILMS), e-resources, IT infrastructure, internet bandwidth, and maintenance systems.',
    detailedOverview: 'Criterion 4 assesses whether the campus provides adequate physical and digital infrastructure to support quality education. Key areas include smart classrooms, laboratory equipment, Integrated Library Management System (ILMS), subscription to e-journals (N-LIST/DELNET), student-computer ratio, Wi-Fi bandwidth, and budget expenditure on maintenance of facilities.',
    weightageAffiliatedUG: 100,
    weightageAffiliatedPG: 100,
    weightageAutonomous: 100,
    weightageUniversity: 100,
    keyIndicators: [
      {
        code: '4.1',
        name: 'Physical Facilities',
        description: 'Adequacy of classrooms, labs, computing equipment, sports facilities, gymnasium, yoga center, cultural auditorium.',
        coreDocuments: ['Geo-tagged photos of all classrooms, labs, sports grounds, and seminar halls', 'Master layout plan of the campus certified by architect/civil engineer', 'Stock registers of laboratory instruments and sports goods']
      },
      {
        code: '4.2',
        name: 'Library as a Learning Resource',
        description: 'ILMS software automation, subscription to e-resources (e-journals, e-books, databases), annual expenditure on books & journals, footfalls.',
        coreDocuments: ['ILMS automation purchase invoice, version details, and AMC', 'N-LIST / DELNET / ShodhSindhu membership receipts & usage logs', 'Accession registers and audited statements showing book/journal purchase', 'Gate register / digital entry logs of library visitors']
      },
      {
        code: '4.3',
        name: 'IT Infrastructure',
        description: 'Student-to-computer ratio, campus Wi-Fi & LAN bandwidth, media center, lecture capturing system (LCS).',
        coreDocuments: ['Stock register entries and purchase invoices of all computers', 'Internet service provider (ISP) bills showing dedicated leased line Mbps', 'Geo-tagged photos of computer labs, server rooms, and recording studio']
      },
      {
        code: '4.4',
        name: 'Maintenance of Campus Infrastructure',
        description: 'Established systems and procedures for maintaining physical, academic, and support facilities, budget allocation and expenditure.',
        coreDocuments: ['Institutional Policy document for maintenance of physical & IT facilities', 'Audited balance sheets with clear entries for maintenance expenditure', 'Annual Maintenance Contracts (AMC) for lifts, generators, computers, RO plants']
      }
    ],
    typicalEvidence: [
      'Geo-tagged photographs of all ICT-enabled classrooms and laboratories',
      'Audited statement of accounts highlighting expenditure on infrastructure augmentation and maintenance',
      'Copy of ILMS software license and screenshots of OPAC (Online Public Access Catalogue)',
      'Internet bandwidth certificate and monthly speed invoices from the ISP',
      'Written institutional maintenance policy manual'
    ],
    preparationChecklist: [
      'Ensure 100% of classrooms have ICT facilities or projection capabilities with geo-tagged images',
      'Verify ILMS is fully automated with accessible Web-OPAC and remote access features',
      'Renew N-LIST / DELNET / e-journal subscriptions continuously without gap years',
      'Maintain an updated computer stock register reflecting student-to-computer ratio (ideally < 1:10)',
      'Ensure audited statements clearly segregate "Infrastructure Augmentation" from "Routine Maintenance"'
    ],
    faqs: [
      {
        question: 'What is the ideal student-to-computer ratio for general colleges?',
        answer: 'NAAC benchmarks recommend a ratio of at least 1 computer for every 10-15 students in general colleges, and 1:2 to 1:4 in engineering and technology institutions.'
      },
      {
        question: 'Is partial library automation acceptable in NAAC?',
        answer: 'While partial automation receives basic credit, full automation with Web-OPAC, barcode/RFID, and remote e-resource access yields maximum scoring in Metric 4.2.1.'
      }
    ],
    manualReferences: [
      {
        title: 'NAAC Infrastructure Standards & Library Guidelines',
        url: 'https://www.naac.gov.in/',
        note: 'Check requirements for geo-tagged photo metadata and ISP bandwidth certifications.'
      }
    ]
  },
  {
    id: 5,
    number: 'Criterion V',
    title: 'Student Support and Progression',
    titleHi: 'छात्र सहायता और प्रगति (Student Support & Progression)',
    titleMr: 'विद्यार्थी सहाय्यता आणि प्रगती (Student Support & Progression)',
    shortDescription: 'Focuses on scholarships, capability enhancement, career guidance, competitive exam coaching, grievance redressal, anti-ragging, student councils, sports/cultural achievements, and registered alumni association.',
    detailedOverview: 'Criterion 5 centers on student welfare and career advancement. It tracks government and institutional scholarships, skill development (soft skills, ICT, language lab), placement percentage, progression to higher education, student representation in statutory bodies, national/international awards in sports and cultural activities, and alumni contributions.',
    weightageAffiliatedUG: 140,
    weightageAffiliatedPG: 130,
    weightageAutonomous: 100,
    weightageUniversity: 100,
    keyIndicators: [
      {
        code: '5.1',
        name: 'Student Support',
        description: 'Scholarships & freeships (Govt & Institutional), capacity building and skills enhancement programs, career counselling & guidance for competitive exams.',
        coreDocuments: ['Govt scholarship disbursement sanction orders & student lists', 'Institutional freeship policy & audited accounts', 'Skill program reports with attendance sheets and circulars', 'Competitive exam guidance logs and student rosters']
      },
      {
        code: '5.2',
        name: 'Student Progression',
        description: 'Placement of outgoing students, progression to higher education (UG to PG, PG to Ph.D.), qualifying in state/national competitive examinations (UGC-NET, GATE, CAT, Civil Services).',
        coreDocuments: ['Official appointment / offer letters of placed students', 'Admission identity cards or fee receipts of students progressing to higher studies', 'Qualifying certificates for NET/SLET/GATE/Civil Services exams']
      },
      {
        code: '5.3',
        name: 'Student Participation and Activities',
        description: 'Awards in sports/cultural activities at inter-university/state/national levels, student council representation in academic and administrative committees.',
        coreDocuments: ['E-copies of award/medal certificates in recognized events', 'Notification of Student Council constitution', 'Minutes of meetings with student representatives on IQAC and committees']
      },
      {
        code: '5.4',
        name: 'Alumni Engagement',
        description: 'Registered Alumni Association, alumni financial contribution, non-financial support (mentoring, placements, guest lectures).',
        coreDocuments: ['Alumni Association Registration Certificate under Societies Act', 'Audited bank statements showing alumni financial donations', 'Reports and photographs of alumni meets and guest lecture sessions']
      }
    ],
    typicalEvidence: [
      'State/Central Government scholarship sanction orders with bank disbursement records',
      'Appointment letters and placement drive offer letters signed by hiring authorities',
      'Admission proofs of graduated students into PG/Ph.D. programs',
      'Anti-Ragging and Internal Complaints Committee (ICC) annual reports and grievance logs',
      'Alumni Society Registration Certificate and audited donation ledger'
    ],
    preparationChecklist: [
      'Maintain an active file of offer letters for every single student claimed under placement',
      'Collect proof of admission (ID card/fee receipt) for every student claimed under progression',
      'Ensure Anti-Ragging, ICC, and Grievance committees meet regularly with uploaded minutes',
      'Register the Alumni Association under the relevant state/central legal registration act',
      'Keep records of competitive examination coaching with attendance and qualifying roll numbers'
    ],
    faqs: [
      {
        question: 'Can an offer letter on WhatsApp or plain email be accepted as placement proof?',
        answer: 'NAAC DVV strictly requires formal appointment letters on corporate letterheads or authenticated campus placement drive registers signed by the company HR and placement officer.'
      },
      {
        question: 'Is registration of the Alumni Association compulsory for full marks in 5.4.1?',
        answer: 'Yes. Quantitative metric 5.4.1 specifically checks for a legally registered Alumni Association under the Societies Registration Act or Section 8 Company.'
      }
    ],
    manualReferences: [
      {
        title: 'NAAC Student Support & Alumni Documentation Guidelines',
        url: 'https://www.naac.gov.in/',
        note: 'Carefully review DVV verification formats for student placement and progression.'
      }
    ]
  },
  {
    id: 6,
    number: 'Criterion VI',
    title: 'Governance, Leadership and Management',
    titleHi: 'शासन, नेतृत्व और प्रबंधन (Governance & Management)',
    titleMr: 'शासन, नेतृत्व आणि व्यवस्थापन (Governance & Management)',
    shortDescription: 'Focuses on institutional vision, decentralization, e-governance, faculty empowerment, financial management, resource mobilization, internal & external audits, and the vital role of the IQAC.',
    detailedOverview: 'Criterion 6 assesses organizational leadership, strategic deployment, participatory management, e-governance implementation, faculty welfare schemes, financial support to attend conferences, Performance Appraisal System (PBAS/API), institutional financial audits, and the proactive functioning of the Internal Quality Assurance Cell (IQAC).',
    weightageAffiliatedUG: 100,
    weightageAffiliatedPG: 100,
    weightageAutonomous: 100,
    weightageUniversity: 100,
    keyIndicators: [
      {
        code: '6.1',
        name: 'Institutional Vision and Leadership',
        description: 'Vision and mission alignment, effective leadership, decentralization and participatory governance across committees.',
        coreDocuments: ['Vision and Mission statements published on campus and website', 'Organogram of the institution showing decision flow', 'Minutes of Governing Body, College Development Committee (CDC), and Academic Council']
      },
      {
        code: '6.2',
        name: 'Strategy Development and Deployment',
        description: 'Strategic plan document and deployment evidence, e-governance implementation in administration, finance, admissions, and examinations.',
        coreDocuments: ['Institutional Strategic / Perspective Plan document (5 years)', 'ERP / Software invoices for e-governance modules', 'Annual e-governance reports approved by Governing Body']
      },
      {
        code: '6.3',
        name: 'Faculty Empowerment Strategies',
        description: 'Welfare measures, financial support to attend conferences/workshops, professional development / administrative training programs organized for staff.',
        coreDocuments: ['Policy document on financial support to teachers for FDPs/conferences', 'Sanction letters and payment vouchers of conference grants', 'Reports of in-house professional development programs organized for teaching and non-teaching staff']
      },
      {
        code: '6.4',
        name: 'Financial Management & Resource Mobilization',
        description: 'Institutional mechanisms for internal and external financial audits, resource mobilization policy, optimal utilization of funds.',
        coreDocuments: ['Internal and External Audit reports signed by certified Chartered Accountants for all 5 years', 'Audit objection compliance statements and Action Taken Reports', 'Resource mobilization and fund utilization policy document']
      },
      {
        code: '6.5',
        name: 'Internal Quality Assurance System (IQAC)',
        description: 'IQAC constitution, regular quarterly meetings and minutes, timely AQAR submission, quality initiatives, academic & administrative audits (AAA), NIRF/ISO rankings.',
        coreDocuments: ['IQAC notification with external stakeholder members as per guidelines', 'Minutes and Action Taken Reports of all IQAC meetings for 5 years', 'AQAR submission acknowledgement receipts from NAAC portal', 'Academic & Administrative Audit (AAA) external reports, ISO certificates, NIRF data']
      }
    ],
    typicalEvidence: [
      'Published Institutional Strategic Plan with documented deployment reviews',
      'Screenshots and user licenses of operational ERP modules across administration and examinations',
      'Vouchers and bank statements showing financial support disbursed to teachers for FDPs',
      'Signed Chartered Accountant audit balance sheets with income-expenditure statements',
      'IQAC meeting proceedings book and formal Academic and Administrative Audit (AAA) reports'
    ],
    preparationChecklist: [
      'Ensure IQAC is constituted strictly as per official NAAC guidelines with external community and industry experts',
      'Conduct at least 4 IQAC meetings per academic year and publish minutes and ATRs online',
      'Submit all Annual Quality Assurance Reports (AQAR) on time on the NAAC HEI portal',
      'Maintain certified financial audit reports without unresolved major audit objections',
      'Conduct external Academic and Administrative Audits (AAA) periodically by peer experts'
    ],
    faqs: [
      {
        question: 'What is the required composition of an institutional IQAC?',
        answer: 'As per NAAC, IQAC should be chaired by the Head of the Institution, include 3-8 senior teachers, 1-2 management members, 1-2 administrative officers, 1 nominee each from local society/students/alumni, 1 nominee from employers/industrialists, and a senior teacher as IQAC Coordinator.'
      },
      {
        question: 'How many meetings must the IQAC conduct in a year?',
        answer: 'The IQAC must convene at least once every quarter (minimum 4 meetings per academic year) with recorded minutes and documented Action Taken Reports (ATRs).'
      }
    ],
    manualReferences: [
      {
        title: 'NAAC Guidelines for the Creation of the Internal Quality Assurance Cell (IQAC)',
        url: 'https://www.naac.gov.in/',
        note: 'Official booklet detailing IQAC structure, objectives, functions, and monitoring mechanisms.'
      }
    ]
  },
  {
    id: 7,
    number: 'Criterion VII',
    title: 'Institutional Values and Best Practices',
    titleHi: 'संस्थागत मूल्य और सर्वोत्तम प्रथाएं (Values & Best Practices)',
    titleMr: 'संस्थागत मूल्ये आणि उत्कृष्ट पद्धती (Values & Best Practices)',
    shortDescription: 'Focuses on gender equity, renewable energy, waste management, water conservation, green campus initiatives, disabled-friendly amenities, professional ethics, two institutional best practices, and institutional distinctiveness.',
    detailedOverview: 'Criterion 7 highlights an institution’s moral, social, and environmental commitment. It assesses gender sensitization initiatives, alternative energy sources (solar, biogas, LED), solid/liquid/e-waste management systems, rainwater harvesting, green audit and energy audit, barrier-free environment for Divyangjan, Code of Conduct, two distinct Institutional Best Practices, and unique Institutional Distinctiveness.',
    weightageAffiliatedUG: 100,
    weightageAffiliatedPG: 100,
    weightageAutonomous: 100,
    weightageUniversity: 100,
    keyIndicators: [
      {
        code: '7.1',
        name: 'Institutional Values & Social Responsibilities',
        description: 'Gender equity action plan, solar energy, waste management, water conservation, green campus audits, disabled-friendly environment, human values and professional ethics.',
        coreDocuments: [
          'Annual gender sensitization action plan and event reports',
          'Geo-tagged photos of solar panels, sensor-based lights, and LED fixtures',
          'Solid, liquid, and e-waste management agreements and facility photos',
          'Rainwater harvesting structures and water conservation reports',
          'Green Audit, Environment Audit, and Energy Audit certificates by certified auditors',
          'Ramps, lifts, disabled-friendly washrooms, and signage photos',
          'Published Code of Conduct handbook for students, teachers, and staff'
        ]
      },
      {
        code: '7.2',
        name: 'Best Practices',
        description: 'Two institutional best practices successfully implemented in the format prescribed by NAAC (Title, Objectives, Context, The Practice, Evidence of Success, Problems Encountered).',
        coreDocuments: ['Formal write-up of Best Practice 1 with photographs, data, and impact report', 'Formal write-up of Best Practice 2 with verifiable outcomes and beneficiary details']
      },
      {
        code: '7.3',
        name: 'Institutional Distinctiveness',
        description: 'One area distinctive to the institution’s priority and thrust that sets it apart from peers (e.g., rural empowerment, tribal education, women leadership, heritage conservation).',
        coreDocuments: ['Detailed narrative write-up on Institutional Distinctiveness (max 1000 words)', 'Supporting documents, statistics, and verifiable outcome evidence published on website']
      }
    ],
    typicalEvidence: [
      'Certified Green Audit, Energy Audit, and Environment Audit reports from accredited agencies',
      'Geo-tagged photos of solar installation, rainwater recharge borewells, compost pits, and ramps',
      'Comprehensive write-ups of two institutional Best Practices formatted according to NAAC guidelines',
      'Institutional Code of Conduct handbook and monitoring committee minutes',
      'Geo-tagged photos of day care center, common rooms, and campus surveillance cameras'
    ],
    preparationChecklist: [
      'Get external Green Audit, Energy Audit, and Environment Audit conducted by certified ISO/Govt approved auditors',
      'Structure the 2 Best Practices strictly under NAAC 6-point format: Title, Objectives, Context, Practice, Evidence of Success, Problems Encountered',
      'Ensure disabled-friendly (Divyangjan) facilities exist: tactile paths, ramps, disabled toilets, assistive software',
      'Install LED lighting (>50% of annual power requirement) and alternative energy sources',
      'Frame an explicit, distinctive Institutional Thrust aligned with institutional vision'
    ],
    faqs: [
      {
        question: 'What is the required structure for NAAC Best Practices in 7.2?',
        answer: 'NAAC mandates a standard 6-part format: 1. Title of the Practice, 2. Objectives of the Practice, 3. The Context, 4. The Practice, 5. Evidence of Success, 6. Problems Encountered and Resources Required.'
      },
      {
        question: 'Who should conduct the Green Audit and Energy Audit for Criterion 7?',
        answer: 'Audits must be conducted by certified energy auditors/managers accredited by the Bureau of Energy Efficiency (BEE) or certified environmental agencies with proper audit stamps and validity dates.'
      }
    ],
    manualReferences: [
      {
        title: 'NAAC Best Practices Framework and Green Campus Guidelines',
        url: 'https://www.naac.gov.in/',
        note: 'Guidelines on format of institutional best practices and environment audit standards.'
      }
    ]
  }
];

export const ACCREDITATION_STAGES_DATA: AccreditationStage[] = [
  {
    id: 1,
    stepNumber: 1,
    title: 'Eligibility Check & IIQA Registration',
    shortDescription: 'Confirm HEI eligibility, register on NAAC portal, and submit Institutional Information for Quality Assessment (IIQA).',
    estimatedTimeline: 'Month 1 - 2',
    detailedGuidance: [
      'Verify that the institution has at least two batches of students graduated, or has been in existence for at least 6 years (whichever is earlier).',
      'Register the institution on the NAAC HEI portal (https://assessmentonline.naac.gov.in).',
      'Fill and submit the IIQA with valid AISHE code, affiliating university 2(f) and 12(B) certificates, statutory approvals (UGC, AICTE, NCTE, BCI, etc.).',
      'Pay the non-refundable IIQA fee online through the payment gateway.',
      'Upon submission, NAAC reviews eligibility within 15 to 30 days.'
    ],
    criticalDocuments: [
      'AISHE (All India Survey on Higher Education) Certificate',
      'UGC 2(f) & 12(B) Recognition letters (if applicable)',
      'Affiliating University permanent/temporary affiliation orders for all offered programs',
      'Statutory regulatory body approval letters (AICTE/PCI/BCI/NCTE)'
    ],
    dosAndDonts: {
      dos: [
        'Ensure the institution name matches letter-by-letter with university affiliation and AISHE portal',
        'Verify that all programs currently running have active statutory approvals',
        'Prepare all IIQA PDF enclosures beforehand in under 5 MB size each'
      ],
      donts: [
        'Do not submit IIQA if a cycle of accreditation is ongoing without checking cycle expiry timelines',
        'Do not list unapproved or expired programs in the academic profile'
      ]
    },
    officialLink: 'https://assessmentonline.naac.gov.in',
    completed: true
  },
  {
    id: 2,
    stepNumber: 2,
    title: 'Review the Latest NAAC Framework & Manual',
    shortDescription: 'Download the exact applicable manual (Affiliated / Autonomous / University / Health Sciences) and review metric weightages.',
    estimatedTimeline: 'Month 2',
    detailedGuidance: [
      'Identify whether your HEI falls under Affiliated UG College, Affiliated PG College, Autonomous College, or University.',
      'Download the latest Revised Accreditation Framework (RAF) manual and Standard Operating Procedures (SOP) for DVV.',
      'Review Qualitative Metrics (QnM vs QlM). Typically, about 70-75% weightage belongs to Quantitative metrics (QnM) and 25-30% to Qualitative metrics (QlM).',
      'Form criterion-wise working committees in the college led by senior faculty members.'
    ],
    criticalDocuments: [
      'Latest NAAC RAF Manual for specific HEI category',
      'Standard Operating Procedure (SOP) for Data Validation & Verification (DVV)',
      'Data Templates Excel format released by NAAC'
    ],
    dosAndDonts: {
      dos: [
        'Organize an institution-wide orientation workshop for all teaching and administrative staff',
        'Map every department head to their respective criterion data contributors'
      ],
      donts: [
        'Do not rely on old manuals from previous years; NAAC updates DVV SOPs frequently',
        'Do not confuse Autonomous manual metrics with Affiliated college metrics'
      ]
    },
    officialLink: 'https://www.naac.gov.in/index.php/en/apply-now',
    completed: true
  },
  {
    id: 3,
    stepNumber: 3,
    title: 'Institutional Data & Evidence Organization',
    shortDescription: 'Collect, audit, and digitize all 5-year data in prescribed NAAC Excel templates with geo-tagged proof.',
    estimatedTimeline: 'Month 2 - 3',
    detailedGuidance: [
      'Populate NAAC quantitative data templates in Excel for the preceding five assessment years.',
      'Ensure every claim has primary documentary evidence (student roll numbers, invoices, sanction letters, CA certificates).',
      'Upload large supporting files to institutional web servers or Google Drive with open view permissions (without restricted passwords).',
      'Ensure all event photographs are geo-tagged with visible timestamp, latitude, and longitude coordinates.',
      'Audit the data internally through an Academic and Administrative Audit (AAA) committee.'
    ],
    criticalDocuments: [
      'Completed NAAC Excel Data Templates for Criteria 1 to 7',
      'Audited Financial statements for all 5 assessment years',
      'Consolidated student database with unique roll numbers, email IDs, and mobile numbers for SSS'
    ],
    dosAndDonts: {
      dos: [
        'Double-check all web links embedded in data templates to ensure they are live and publicly accessible',
        'Verify that student and faculty counts remain consistent across all criteria'
      ],
      donts: [
        'Do not use password-protected drive links or broken institutional server URLs',
        'Do not edit or distort dates on official certificates or bills'
      ]
    },
    officialLink: 'https://www.naac.gov.in/',
    completed: false
  },
  {
    id: 4,
    stepNumber: 4,
    title: 'Self Study Report (SSR) Preparation & Submission',
    shortDescription: 'Draft executive summary, write qualitative narratives, upload data templates, and submit SSR within 45 days of IIQA approval.',
    estimatedTimeline: 'Month 3 - 4',
    detailedGuidance: [
      'Once IIQA is accepted by NAAC, the college has strictly 45 days to complete and submit the Self Study Report (SSR) online.',
      'Draft concise, evidence-grounded narratives for Qualitative Metrics (QlM) adhering to character limits (typically 500 words per metric).',
      'Upload the filled Excel templates for Quantitative Metrics (QnM) and paste direct website URLs for documentary proof.',
      'Submit the accurate Student database for the Student Satisfaction Survey (SSS).',
      'Pay the first installment of the accreditation assessment fee online.',
      'Submit the SSR before the midnight deadline of day 45.'
    ],
    criticalDocuments: [
      'Executive Summary & Institutional Profile write-up',
      'Qualitative metric essays (QlM) with proof links',
      'Signed compliance undertakings and declarations by the Principal'
    ],
    dosAndDonts: {
      dos: [
        'Submit at least 3-4 days ahead of the 45-day deadline to avoid last-minute portal server congestion',
        'Verify that the Principal and IQAC Coordinator review every qualitative narrative'
      ],
      donts: [
        'Do not miss the 45-day deadline; failure to submit results in cancellation of IIQA and forfeiture of fees',
        'Do not paste repetitive generic text in qualitative metrics'
      ]
    },
    officialLink: 'https://assessmentonline.naac.gov.in',
    completed: false
  },
  {
    id: 5,
    stepNumber: 5,
    title: 'Data Validation and Verification (DVV) Process',
    shortDescription: 'Respond to online queries raised by third-party DVV partners within the strict 15-day window.',
    estimatedTimeline: 'Month 4 - 5',
    detailedGuidance: [
      'NAAC forwards all quantitative data to independent DVV agency teams for rigorous mathematical and evidentiary verification.',
      'DVV scrutinizes claims and issues clarifications or asks for sample documents (e.g., specific student certificates, CA certificates).',
      'The HEI receives a notification on the portal and email, with strictly 15 days to answer all DVV queries.',
      'Upload attested documents, revised templates (if requested), and specific clarifications signed by the Principal.',
      'DVV generates the final Pre-Qualifier Score based on verified quantitative data.'
    ],
    criticalDocuments: [
      'Attested copies of sample documents requested by DVV',
      'Chartered Accountant certificates for financial metrics',
      'Official response letter signed and stamped by the Head of the Institution'
    ],
    dosAndDonts: {
      dos: [
        'Respond to every query systematically with clear cross-referencing and indexed page numbers',
        'Provide high-resolution scans of original documents with institutional seal and signature'
      ],
      donts: [
        'Do not exceed the 15-day response timeline under any circumstances',
        'Do not submit altered or non-attested documents'
      ]
    },
    officialLink: 'https://assessmentonline.naac.gov.in',
    completed: false
  },
  {
    id: 6,
    stepNumber: 6,
    title: 'Student Satisfaction Survey (SSS) Execution',
    shortDescription: 'NAAC administers the online survey directly to enrolled students based on institutional student lists.',
    estimatedTimeline: 'Month 4 - 5 (Concurrent with DVV)',
    detailedGuidance: [
      'Concurrently with DVV, NAAC triggers the automated online SSS (21 questions regarding teaching, evaluation, mentoring).',
      'For colleges, a minimum of 10% of total student enrollment or 100 students (whichever is less) must respond for survey validity.',
      'For universities, a minimum of 10% or 500 students must respond.',
      'Educate students about checking their email inboxes and spam folders for official NAAC survey links.',
      'The survey score is computed algorithmically and added to Criterion 2 score.'
    ],
    criticalDocuments: [
      'Student communication roster and awareness notices',
      'Student email/SMS contact validation log'
    ],
    dosAndDonts: {
      dos: [
        'Conduct orientation sessions explaining the importance of objective student feedback',
        'Encourage students to complete the survey promptly upon receiving the NAAC email'
      ],
      donts: [
        'Do not attempt to fill the survey on behalf of students; NAAC tracks IP addresses and flags irregularities',
        'Do not coach students to give false or manipulated answers'
      ]
    },
    officialLink: 'https://www.naac.gov.in/',
    completed: false
  },
  {
    id: 7,
    stepNumber: 7,
    title: 'Pre-Qualifier Result & Peer Team Visit (PTV)',
    shortDescription: 'Clear the 25% pre-qualification hurdle, pay visit fees, host the NAAC Peer Team on campus for on-site validation.',
    estimatedTimeline: 'Month 5 - 6',
    detailedGuidance: [
      'The HEI must score at least 25% marks in Quantitative Metrics (QnM) during DVV to clear the Pre-Qualifier stage.',
      'Upon clearing Pre-Qualifier, the HEI submits convenient visit dates and pays the remaining second installment of assessment fees.',
      'NAAC constitutes a Peer Team of eminent Vice-Chancellors, Professors, and Principals.',
      'The Peer Team visits the campus for 2 days to verify qualitative metrics (QlM), inspect physical facilities, interact with students, teachers, parents, alumni, and governing body.',
      'The Peer Team hands over the draft Qualitative Report in a formal Exit Meeting.'
    ],
    criticalDocuments: [
      'Printed and indexed criterion master files with physical evidence in the IQAC room',
      'Presentation slides for Principal and IQAC Coordinator',
      'Campus route map, interaction schedules, and cultural program brief'
    ],
    dosAndDonts: {
      dos: [
        'Arrange a dedicated, well-organized IQAC room where all files are clearly labeled criterion-wise',
        'Ensure open and cordial interaction sessions with all stakeholder groups'
      ],
      donts: [
        'Do not offer personal gifts or extravagant arrangements violating NAAC code of conduct',
        'Do not argue or challenge Peer Team members during on-site inspections'
      ]
    },
    officialLink: 'https://www.naac.gov.in/',
    completed: false
  },
  {
    id: 8,
    stepNumber: 8,
    title: 'Declaration of Results, Grading & Post-Accreditation AQARs',
    shortDescription: 'Receive final CGPA & Grade from Standing Committee, publish certificate, and start annual AQAR cycle.',
    estimatedTimeline: 'Month 7 onward',
    detailedGuidance: [
      'The NAAC Standing Committee compiles the System Generated Score (DVV + SSS) with the Peer Team Qualitative Score to determine the Cumulative Grade Point Average (CGPA).',
      'Grades are awarded: A++ (3.51 - 4.00), A+ (3.26 - 3.50), A (3.01 - 3.25), B++ (2.76 - 3.00), B+ (2.51 - 2.75), B (2.01 - 2.50), C (1.51 - 2.00), D (<=1.50, Not Accredited).',
      'The result is notified on the NAAC website and the accreditation status remains valid for 5 years.',
      'The institution must display the NAAC certificate and Grade prominently.',
      'Submit Annual Quality Assurance Reports (AQAR) online every year to maintain accreditation continuity for the next cycle.'
    ],
    criticalDocuments: [
      'Official NAAC Accreditation Certificate and Peer Team Evaluation Report',
      'Post-Accreditation Action Plan prepared by IQAC',
      'Subsequent Annual Quality Assurance Reports (AQAR 1 to AQAR 5)'
    ],
    dosAndDonts: {
      dos: [
        'Analyze the Peer Team Report recommendations and formulate an immediate 5-year quality enhancement roadmap',
        'Ensure timely submission of AQARs annually to remain eligible for subsequent accreditation cycles'
      ],
      donts: [
        'Do not become complacent after getting a good grade; continuous quality improvement is audited annually'
      ]
    },
    officialLink: 'https://www.naac.gov.in/',
    completed: false
  }
];

export const INITIAL_DOCUMENTS: DocumentItem[] = [
  {
    id: 'doc-1',
    title: 'Institutional Academic Calendar with Committee Approvals',
    description: 'Master academic calendar showing semester dates, CIE schedules, holidays, and extracurricular events, duly approved by College Development Committee (CDC) or Academic Council.',
    criterionId: 1,
    category: 'Academic Records',
    academicYear: '2025-2026',
    responsibleDepartment: 'IQAC & Academic Committee',
    status: 'Completed',
    lastUpdated: '2026-09-10',
    notes: 'Published on institutional website homepage and distributed to all departments.',
    verifiedMandatory: true
  },
  {
    id: 'doc-2',
    title: '4-Tier Stakeholder Feedback Analysis & Action Taken Reports (ATR)',
    description: 'Structured feedback questionnaires, tabulated statistical data, and documented Action Taken Reports from Students, Teachers, Employers, and Alumni.',
    criterionId: 1,
    category: 'Feedback & Quality',
    academicYear: '2025-2026',
    responsibleDepartment: 'IQAC Cell',
    status: 'In Progress',
    lastUpdated: '2026-10-02',
    notes: 'Employer feedback data collection in progress; alumni and student feedback analysis completed.',
    verifiedMandatory: true
  },
  {
    id: 'doc-3',
    title: 'Add-on / Certificate Course Syllabi & Completion Records',
    description: 'Curriculum structure (>30 contact hours), student registration lists, attendance logs, and sample course completion certificates.',
    criterionId: 1,
    category: 'Academic Records',
    academicYear: '2025-2026',
    responsibleDepartment: 'Computer Science & Commerce',
    status: 'Completed',
    lastUpdated: '2026-08-25',
    notes: '12 certificate courses concluded with 420 certified students.',
    verifiedMandatory: true
  },
  {
    id: 'doc-4',
    title: 'Consolidated Student Database for SSS Portal (2025-26)',
    description: 'Clean verified list of all enrolled students with distinct roll number, program, year, mobile number, and verified personal email ID.',
    criterionId: 2,
    category: 'Student Support',
    academicYear: '2025-2026',
    responsibleDepartment: 'Admissions & IT Cell',
    status: 'In Progress',
    lastUpdated: '2026-10-12',
    notes: 'Phone numbers verified via SMS test. Ready for upload during SSR.',
    verifiedMandatory: true
  },
  {
    id: 'doc-5',
    title: 'Course Outcomes (CO) & Program Outcomes (PO) Attainment Spreadsheets',
    description: 'Documented direct and indirect attainment evaluation sheets mapping internal examination marks and university exams to course learning outcomes.',
    criterionId: 2,
    category: 'Academic Records',
    academicYear: '2024-2025',
    responsibleDepartment: 'All Academic Departments',
    status: 'In Progress',
    lastUpdated: '2026-09-30',
    notes: 'Science and Commerce departments completed; Arts faculty calculation pending.',
    verifiedMandatory: true
  },
  {
    id: 'doc-6',
    title: 'Mentor-Mentee Allocation Registers & Counselling Logs',
    description: 'Official circular assigning faculty mentors to student batches, with recorded meeting minutes and personal/academic counselling notes.',
    criterionId: 2,
    category: 'Student Support',
    academicYear: '2025-2026',
    responsibleDepartment: 'Student Welfare Committee',
    status: 'Completed',
    lastUpdated: '2026-09-15',
    notes: 'Ratio maintained at 1:18. All log books signed by Principal.',
    verifiedMandatory: true
  },
  {
    id: 'doc-7',
    title: 'UGC-CARE / Scopus Research Publication Repository',
    description: 'Indexed list of published research papers with title, journal name, ISSN, impact factor, author affiliation, and direct UGC-CARE link.',
    criterionId: 3,
    category: 'Research & Publications',
    academicYear: '2025-2026',
    responsibleDepartment: 'Research Advisory Committee',
    status: 'In Progress',
    lastUpdated: '2026-10-05',
    notes: '38 papers verified against latest UGC-CARE group listing.',
    verifiedMandatory: true
  },
  {
    id: 'doc-8',
    title: 'Signed MoUs & Documented Collaborative Activity Reports',
    description: 'Legal MoU agreements on stamp papers with verified activity completion letters, guest lectures, student internships, and faculty exchanges.',
    criterionId: 3,
    category: 'Extension & Collaborations',
    academicYear: '2025-2026',
    responsibleDepartment: 'Industry-Institute Partnership Cell',
    status: 'Not Started',
    lastUpdated: '2026-07-20',
    notes: 'Need to compile tangible evidence for 6 existing MoUs.',
    verifiedMandatory: true
  },
  {
    id: 'doc-9',
    title: 'ILMS Software Automation License & Web-OPAC Receipts',
    description: 'Invoices, AMC agreements, version specifications for Integrated Library Management Software, along with remote e-resource subscription proofs (N-LIST).',
    criterionId: 4,
    category: 'Infrastructure',
    academicYear: '2025-2026',
    responsibleDepartment: 'Central Library',
    status: 'Completed',
    lastUpdated: '2026-08-14',
    notes: 'Kohla ILMS fully operational; N-LIST subscription active till March 2027.',
    verifiedMandatory: true
  },
  {
    id: 'doc-10',
    title: 'Internet Leased Line Bandwidth Certificate & ISP Invoices',
    description: 'Official monthly speed invoices and bandwidth certificates from ISP showing dedicated campus internet speed (e.g., 200 Mbps).',
    criterionId: 4,
    category: 'Infrastructure',
    academicYear: '2025-2026',
    responsibleDepartment: 'IT & Network Admin',
    status: 'Completed',
    lastUpdated: '2026-09-01',
    notes: 'Leased line certificate verified at 300 Mbps symmetrical.',
    verifiedMandatory: true
  },
  {
    id: 'doc-11',
    title: 'Student Placement Appointment Letters & Higher Education Proofs',
    description: 'Documented offer letters on corporate letterheads and PG/Ph.D. admission proof receipts for graduating batch.',
    criterionId: 5,
    category: 'Student Support',
    academicYear: '2024-2025',
    responsibleDepartment: 'Training & Placement Cell',
    status: 'In Progress',
    lastUpdated: '2026-10-08',
    notes: '142 offer letters compiled in drive; higher education proofs being collected from alumni.',
    verifiedMandatory: true
  },
  {
    id: 'doc-12',
    title: 'Registered Alumni Association Certificate & Financial Ledger',
    description: 'Certificate of registration under Societies Act, audited bank statements showing alumni monetary donations, and annual meeting minutes.',
    criterionId: 5,
    category: 'Governance & Administration',
    academicYear: '2025-2026',
    responsibleDepartment: 'Alumni Association Committee',
    status: 'Completed',
    lastUpdated: '2026-08-30',
    notes: 'Registered under Maharashtra Public Trusts Act / Societies Act.',
    verifiedMandatory: true
  },
  {
    id: 'doc-13',
    title: 'Audited Financial Statements by Chartered Accountant (5-Year)',
    description: 'Balance sheets, Income-Expenditure accounts, and audit notes for the past 5 consecutive financial years with distinct CA registration numbers.',
    criterionId: 6,
    category: 'Governance & Administration',
    academicYear: '2021-2026',
    responsibleDepartment: 'Accounts & Finance',
    status: 'Completed',
    lastUpdated: '2026-09-22',
    notes: 'Separate CA certificates drafted for Infrastructure Augmentation and Maintenance.',
    verifiedMandatory: true
  },
  {
    id: 'doc-14',
    title: 'IQAC Meeting Minutes and Quarterly Action Taken Reports (ATRs)',
    description: 'Signed proceedings of all 4 quarterly IQAC meetings per year, including external expert attendance and resolution implementation reports.',
    criterionId: 6,
    category: 'Feedback & Quality',
    academicYear: '2025-2026',
    responsibleDepartment: 'IQAC Cell',
    status: 'Completed',
    lastUpdated: '2026-10-10',
    notes: 'Meeting minutes uploaded to website IQAC tab.',
    verifiedMandatory: true
  },
  {
    id: 'doc-15',
    title: 'Green Audit, Environment Audit & Energy Audit Reports',
    description: 'External audit reports conducted by certified auditors assessing solar power, water conservation, e-waste, and carbon footprint reduction.',
    criterionId: 7,
    category: 'Infrastructure',
    academicYear: '2025-2026',
    responsibleDepartment: 'Environmental Studies & Estate',
    status: 'Completed',
    lastUpdated: '2026-09-18',
    notes: 'Conducted by BEE certified energy auditor agency with valid 3-year certification.',
    verifiedMandatory: true
  },
  {
    id: 'doc-16',
    title: 'Two Institutional Best Practices Structured Write-Ups (NAAC Format)',
    description: 'Documented 6-point reports: (1) Title, (2) Objectives, (3) Context, (4) Practice, (5) Evidence of Success, and (6) Problems Encountered with photo albums.',
    criterionId: 7,
    category: 'Feedback & Quality',
    academicYear: '2025-2026',
    responsibleDepartment: 'IQAC Cell',
    status: 'In Progress',
    lastUpdated: '2026-10-04',
    notes: 'Best Practice 1 (Rural Digital Literacy) finalized; Best Practice 2 (Water Conservation) draft in review.',
    verifiedMandatory: true
  }
];

export const OFFICIAL_RESOURCES_DATA: OfficialResource[] = [
  {
    id: 'res-1',
    title: 'National Assessment and Accreditation Council (NAAC) Official Portal',
    category: 'Portal',
    description: 'The primary central portal for NAAC notifications, announcements, institution search, and national accreditation policies.',
    url: 'https://www.naac.gov.in/',
    publicationDate: 'Official Portal',
    lastVerifiedDate: '2026-10-01',
    isVerified: true
  },
  {
    id: 'res-2',
    title: 'NAAC HEI Assessment Online Portal (A&A)',
    category: 'Portal',
    description: 'The dedicated portal for Higher Education Institutions to register, submit IIQA, upload SSR, receive DVV clarifications, and track assessment progress.',
    url: 'https://assessmentonline.naac.gov.in/',
    publicationDate: 'Active Portal',
    lastVerifiedDate: '2026-10-01',
    isVerified: true
  },
  {
    id: 'res-3',
    title: 'NAAC Assessment Manual for Affiliated / Constituent Colleges',
    category: 'Manual',
    description: 'Comprehensive manual detailing the 7 criteria, Key Indicators (KIs), Qualitative vs Quantitative metrics, weightages, and required evidence.',
    url: 'https://www.naac.gov.in/index.php/en/apply-now',
    publicationDate: '2024 Revised Edition',
    lastVerifiedDate: '2026-09-15',
    isVerified: true,
    fileType: 'PDF'
  },
  {
    id: 'res-4',
    title: 'Standard Operating Procedures (SOP) for Data Validation & Verification (DVV)',
    category: 'Guideline',
    description: 'Official DVV guidelines detailing acceptable evidentiary documents, exclusions, formula specifications, and verification rules.',
    url: 'https://www.naac.gov.in/',
    publicationDate: 'Regularly Updated',
    lastVerifiedDate: '2026-09-20',
    isVerified: true,
    fileType: 'PDF'
  },
  {
    id: 'res-5',
    title: 'Guidelines for the Creation & Functioning of IQAC in Higher Educational Institutions',
    category: 'Guideline',
    description: 'Official statutory booklet prescribing IQAC objectives, composition, operational mechanisms, goals, and role of the coordinator.',
    url: 'https://www.naac.gov.in/',
    publicationDate: 'Official Guideline',
    lastVerifiedDate: '2026-09-10',
    isVerified: true,
    fileType: 'PDF'
  },
  {
    id: 'res-6',
    title: 'Annual Quality Assurance Report (AQAR) Guidelines & Formats',
    category: 'Format',
    description: 'Official guidelines and reporting templates for submitting annual institutional quality reports to maintain accreditation standing.',
    url: 'https://www.naac.gov.in/',
    publicationDate: 'Annual Framework',
    lastVerifiedDate: '2026-09-05',
    isVerified: true,
    fileType: 'PDF'
  },
  {
    id: 'res-7',
    title: 'Student Satisfaction Survey (SSS) Questionnaire & Execution Protocols',
    category: 'Guideline',
    description: 'Detailed instructions and list of 21 standard questions administered online by NAAC directly to randomly selected enrolled students.',
    url: 'https://www.naac.gov.in/',
    publicationDate: 'National Standard',
    lastVerifiedDate: '2026-08-28',
    isVerified: true,
    fileType: 'PDF'
  },
  {
    id: 'res-8',
    title: 'University Grants Commission (UGC) Higher Education Regulatory Guidelines',
    category: 'Guideline',
    description: 'Regulatory circulars, 2(f) and 12(B) criteria, faculty appointment standards, and national education policy integration directives.',
    url: 'https://www.ugc.gov.in/',
    publicationDate: 'Statutory Body',
    lastVerifiedDate: '2026-09-12',
    isVerified: true
  }
];

export const FAQ_DATA: FAQItem[] = [
  {
    id: 'faq-1',
    category: 'NAAC Basics',
    question: 'What is NAAC and why is accreditation vital for higher education institutions?',
    answer: 'The National Assessment and Accreditation Council (NAAC) is an autonomous body established by the University Grants Commission (UGC) of India to assess and accredit institutions of higher learning. Accreditation evaluates the overall institutional performance in governance, academic excellence, faculty quality, research, infrastructure, and student support. It is essential for UGC developmental grants, academic autonomy, global recognition, and continuous quality enhancement.',
    officialRef: 'NAAC Act & UGC Mandate',
    tags: ['basics', 'overview', 'ugc']
  },
  {
    id: 'faq-2',
    category: 'IQAC',
    question: 'What is the role of the Internal Quality Assurance Cell (IQAC)?',
    answer: 'The IQAC is the internal engine for institutional quality enhancement. Its primary responsibilities include: (1) Developing realistic quality benchmarks for academic and administrative activities, (2) Facilitating a student-centric learning environment, (3) Collecting and analyzing feedback from students, teachers, employers, and alumni, (4) Organizing faculty development workshops and quality circles, (5) Documenting institutional programs and quality initiatives, (6) Preparing and submitting Annual Quality Assurance Reports (AQAR) to NAAC.',
    officialRef: 'NAAC IQAC Guidelines',
    tags: ['iqac', 'quality', 'governance']
  },
  {
    id: 'faq-3',
    category: 'Documentation',
    question: 'What is the difference between SSR and AQAR?',
    answer: 'The Self Study Report (SSR) is a comprehensive 5-year assessment report submitted once per accreditation cycle during the formal assessment process. It includes both Quantitative (QnM) and Qualitative (QlM) metrics across all 7 criteria. In contrast, the Annual Quality Assurance Report (AQAR) is an annual progress report submitted online every year by an already accredited institution to document continuous quality measures implemented by the IQAC during that academic year.',
    officialRef: 'RAF Guidelines',
    tags: ['ssr', 'aqar', 'comparison']
  },
  {
    id: 'faq-4',
    category: 'Accreditation Process',
    question: 'What is the DVV (Data Validation and Verification) process?',
    answer: 'DVV is a rigorous, objective online verification process conducted by independent external validation partners appointed by NAAC. The DVV team scrutinizes every numerical data claim submitted in the quantitative Excel templates of the SSR against uploaded documentary evidence, invoices, certificates, and student rosters. DVV may issue queries requiring institutions to provide clarifications or authentic scanned proofs within a strict 15-day deadline.',
    officialRef: 'NAAC DVV Standard Operating Procedure',
    tags: ['dvv', 'verification', 'process']
  },
  {
    id: 'faq-5',
    category: 'Assessment Criteria',
    question: 'How are the seven NAAC criteria weighted across institution types?',
    answer: 'The seven criteria carry a total of 1000 marks. For Affiliated UG Colleges: Criterion 1 (100), Criterion 2 (350), Criterion 3 (110), Criterion 4 (100), Criterion 5 (140), Criterion 6 (100), Criterion 7 (100). For Autonomous Colleges: Criterion 1 (150), Criterion 2 (300), Criterion 3 (150), Criterion 4 (100), Criterion 5 (100), Criterion 6 (100), Criterion 7 (100). Note that Criterion 2 (Teaching-Learning) holds the largest share across affiliated institutions.',
    officialRef: 'NAAC RAF Manuals',
    tags: ['criteria', 'weightage', 'marks']
  },
  {
    id: 'faq-6',
    category: 'Grading & Outcomes',
    question: 'How does NAAC determine the final CGPA and Grade?',
    answer: 'The final grade is derived from the Cumulative Grade Point Average (CGPA) on a 4-point scale: A++ (3.51 - 4.00, Outstanding), A+ (3.26 - 3.50, Excellent), A (3.01 - 3.25, Very Good), B++ (2.76 - 3.00, Good), B+ (2.51 - 2.75, Above Average), B (2.01 - 2.50, Average), C (1.51 - 2.00, Satisfactory), and D (<= 1.50, Not Accredited). The score combines the System Generated Score (DVV + SSS) with Peer Team Qualitative Evaluation.',
    officialRef: 'NAAC Grading System Policy',
    tags: ['grades', 'cgpa', 'scores']
  },
  {
    id: 'faq-7',
    category: 'Quality Assurance',
    question: 'What are the main responsibilities of an institutional NAAC Coordinator?',
    answer: 'The NAAC Coordinator leads the accreditation preparation. Key duties include: (1) Formulating criterion-wise task forces, (2) Overseeing the collection and cross-auditing of 5-year evidentiary records, (3) Ensuring adherence to NAAC data formats and DVV guidelines, (4) Liaising with the Principal and management for required resources, (5) Coordinating timely submission of IIQA, SSR, and DVV clarifications, (6) Organizing on-site logistics for the Peer Team Visit.',
    officialRef: 'Institutional Best Practice Guide',
    tags: ['coordinator', 'roles', 'iqac']
  },
  {
    id: 'faq-8',
    category: 'Accreditation Updates',
    question: 'What is the recent development regarding Binary Accreditation and Maturity-based Graded Accreditation?',
    answer: 'The Radhakrishnan Committee recommendations accepted by the Ministry of Education introduce two transformative reforms: (1) Binary Accreditation (Accredited vs Not Accredited) to encourage all institutions to meet baseline quality, and (2) Maturity-based Graded Accreditation (Level 1 to Level 5) to foster global excellence. Institutions should continuously check the official NAAC portal (https://www.naac.gov.in) for transition timelines and applicable framework notices.',
    officialRef: 'National Reforms & Radhakrishnan Committee Report',
    tags: ['reforms', 'binary', 'updates']
  }
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Transition Towards Binary Accreditation and Maturity-based Graded System',
    date: '2026-08-20',
    summary: 'Higher Education Institutions are advised to follow official NAAC circulars regarding the phased implementation of binary accreditation and maturity levels.',
    link: 'https://www.naac.gov.in/',
    badge: 'Framework',
    isActive: true
  },
  {
    id: 'ann-2',
    title: 'Advisory on Mandatory Geo-Tagged Photographs and Web Link Protocols',
    date: '2026-07-15',
    summary: 'DVV partner agencies will verify timestamp, latitude, and longitude metadata on all institutional event photographs submitted for Criteria 1, 3, 4, and 7.',
    link: 'https://www.naac.gov.in/',
    badge: 'Advisory',
    isActive: true
  },
  {
    id: 'ann-3',
    title: 'Student Satisfaction Survey (SSS) Database Verification Protocol',
    date: '2026-06-10',
    summary: 'HEIs must ensure mobile numbers and email addresses in the student roster match active student communication channels to ensure valid survey response ratios.',
    link: 'https://www.naac.gov.in/',
    badge: 'Manual Update',
    isActive: true
  }
];
