import { DocumentItem, AccreditationStage, OfficialResource, FAQItem, Announcement, User, AdminStats, Language } from '../types';

export const api = {
  async sendChatMessage(payload: {
    message: string;
    language: Language;
    history?: { sender: 'user' | 'bot'; text: string }[];
    userRole?: string;
  }) {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to get answer from NAAC AI assistant');
    }
    return res.json();
  },

  async sendFeedback(logId: string, feedback: 'helpful' | 'unhelpful') {
    const res = await fetch('/api/chat/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ logId, feedback })
    });
    return res.json();
  },

  async getDocuments(params?: { criterion?: string; status?: string; year?: string; search?: string }): Promise<DocumentItem[]> {
    const query = new URLSearchParams();
    if (params?.criterion) query.set('criterion', params.criterion);
    if (params?.status) query.set('status', params.status);
    if (params?.year) query.set('year', params.year);
    if (params?.search) query.set('search', params.search);

    const res = await fetch(`/api/documents?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to load documents');
    return res.json();
  },

  async createDocument(doc: Partial<DocumentItem>): Promise<DocumentItem> {
    const res = await fetch('/api/documents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(doc)
    });
    if (!res.ok) throw new Error('Failed to create document checklist item');
    return res.json();
  },

  async updateDocument(id: string, doc: Partial<DocumentItem>): Promise<DocumentItem> {
    const res = await fetch(`/api/documents/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(doc)
    });
    if (!res.ok) throw new Error('Failed to update document');
    return res.json();
  },

  async deleteDocument(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`/api/documents/${id}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Failed to delete document');
    return res.json();
  },

  async getStages(): Promise<AccreditationStage[]> {
    const res = await fetch('/api/stages');
    if (!res.ok) throw new Error('Failed to load accreditation stages');
    return res.json();
  },

  async toggleStage(stageId: number): Promise<AccreditationStage> {
    const res = await fetch('/api/stages/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stageId })
    });
    if (!res.ok) throw new Error('Failed to update stage');
    return res.json();
  },

  async getResources(): Promise<OfficialResource[]> {
    const res = await fetch('/api/resources');
    if (!res.ok) throw new Error('Failed to load official resources');
    return res.json();
  },

  async createResource(resource: Partial<OfficialResource>): Promise<OfficialResource> {
    const res = await fetch('/api/resources', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(resource)
    });
    if (!res.ok) throw new Error('Failed to save resource');
    return res.json();
  },

  async getFaqs(): Promise<FAQItem[]> {
    const res = await fetch('/api/faqs');
    if (!res.ok) throw new Error('Failed to load FAQs');
    return res.json();
  },

  async createFaq(faq: Partial<FAQItem>): Promise<FAQItem> {
    const res = await fetch('/api/faqs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(faq)
    });
    if (!res.ok) throw new Error('Failed to save FAQ');
    return res.json();
  },

  async getAnnouncements(): Promise<Announcement[]> {
    const res = await fetch('/api/announcements');
    if (!res.ok) throw new Error('Failed to load announcements');
    return res.json();
  },

  async createAnnouncement(ann: Partial<Announcement>): Promise<Announcement> {
    const res = await fetch('/api/announcements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ann)
    });
    if (!res.ok) throw new Error('Failed to save announcement');
    return res.json();
  },

  async deleteAnnouncement(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`/api/announcements/${id}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Failed to delete announcement');
    return res.json();
  },

  async login(email: string): Promise<{ user: User; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    if (!res.ok) throw new Error('Login failed');
    return res.json();
  },

  async register(data: { name: string; email: string; institution: string; role: string }): Promise<{ user: User; token: string }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Registration failed');
    return res.json();
  },

  async getAdminStats(): Promise<AdminStats> {
    const res = await fetch('/api/admin/stats');
    if (!res.ok) throw new Error('Failed to fetch admin stats');
    return res.json();
  }
};
