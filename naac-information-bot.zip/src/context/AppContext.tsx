import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Language, UserRole } from '../types';
import { api } from '../services/api';

export type NavTab = 'home' | 'chat' | 'criteria' | 'documents' | 'process' | 'resources' | 'faq' | 'admin';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  isDark: boolean;
  toggleTheme: () => void;
  currentUser: User | null;
  login: (email: string) => Promise<void>;
  register: (name: string, email: string, institution: string, role: UserRole) => Promise<void>;
  logout: () => void;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  chatInitialPrompt: string;
  setChatInitialPrompt: (prompt: string) => void;
  startChatWithQuery: (query: string) => void;
  selectedCriterionId: number | null;
  setSelectedCriterionId: (id: number | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [language, setLanguage] = useState<Language>('en');
  const [isDark, setIsDark] = useState<boolean>(() => {
    return localStorage.getItem('naac_theme') === 'dark';
  });
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('naac_user');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.name === 'Dr. Rajesh Sharma') {
          parsed.name = 'Gauri Patil';
          localStorage.setItem('naac_user', JSON.stringify(parsed));
        }
        return parsed;
      } catch { return null; }
    }
    // Default logged in as NAAC Coordinator for effortless instant demo
    return {
      id: 'user-coord-1',
      name: 'Gauri Patil',
      email: 'coordinator@college.edu',
      institution: 'Vidya Vikas College of Arts, Science & Commerce',
      role: 'coordinator',
      createdAt: '2026-01-15'
    };
  });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [chatInitialPrompt, setChatInitialPrompt] = useState<string>('');
  const [selectedCriterionId, setSelectedCriterionId] = useState<number | null>(null);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('naac_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('naac_theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(prev => !prev);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = 'toast-' + Date.now() + Math.random();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const login = async (email: string) => {
    try {
      const res = await api.login(email);
      setCurrentUser(res.user);
      localStorage.setItem('naac_user', JSON.stringify(res.user));
      showToast(`Welcome, ${res.user.name}!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Login failed', 'error');
      throw err;
    }
  };

  const register = async (name: string, email: string, institution: string, role: UserRole) => {
    try {
      const res = await api.register({ name, email, institution, role });
      setCurrentUser(res.user);
      localStorage.setItem('naac_user', JSON.stringify(res.user));
      showToast(`Registration successful! Welcome, ${res.user.name}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Registration failed', 'error');
      throw err;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('naac_user');
    showToast('You have been logged out', 'info');
  };

  const startChatWithQuery = (query: string) => {
    setChatInitialPrompt(query);
    setActiveTab('chat');
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        language,
        setLanguage,
        isDark,
        toggleTheme,
        currentUser,
        login,
        register,
        logout,
        toasts,
        showToast,
        removeToast,
        chatInitialPrompt,
        setChatInitialPrompt,
        startChatWithQuery,
        selectedCriterionId,
        setSelectedCriterionId
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
