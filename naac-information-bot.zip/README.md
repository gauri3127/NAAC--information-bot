# NAAC Information Bot

An intelligent, AI-powered NAAC guidance and accreditation assistant designed for students, teachers, college NAAC coordinators, IQAC members, and institutional administrators.

The application simplifies understanding of NAAC accreditation, assessment criteria, required evidentiary documentation, institutional quality assurance, and accreditation procedures.

---

## 🌟 Key Features

1. **Intelligent Conversational AI (Gemini 3.8 Flash)**
   - Answers NAAC-related queries in plain, accessible language.
   - Multilingual support: **English**, **हिन्दी (Hindi)**, and **मराठी (Marathi)**.
   - Formatted output with markdown headings, numbered steps, structured tables, and key takeaways.
   - Grounded in official NAAC Revised Accreditation Framework (RAF) and DVV Standard Operating Procedures (SOP).
   - Interactive features: copy response, export response as PDF, helpful/unhelpful feedback logging, and suggested follow-up questions.

2. **The Seven NAAC Assessment Criteria Explorer**
   - Detailed interactive guide for Criteria 1 through 7:
     1. Curricular Aspects
     2. Teaching-Learning and Evaluation
     3. Research, Innovations and Extension
     4. Infrastructure and Learning Resources
     5. Student Support and Progression
     6. Governance, Leadership and Management
     7. Institutional Values and Best Practices
   - Comparative marks weightage breakdown across Affiliated UG, Affiliated PG, Autonomous, and University frameworks.
   - Key Indicators (KIs), required core evidence, and interactive readiness checklists.

3. **Institutional Documentation Guide & Evidence Checklist**
   - Dynamic evidence tracker organized criterion-wise and category-wise.
   - Status tracking: *Not Started*, *In Progress*, *Completed*.
   - Filter by criterion, status, academic year, and department.
   - Add, edit, delete checklist items with persistent storage.
   - Export evidence checklist as **CSV** or **PDF**.
   - Visual progress indicators and institutional readiness index.

4. **Accreditation Process Journey**
   - 8-stage step-by-step roadmap:
     1. Eligibility & IIQA Registration
     2. Framework & Manual Review
     3. Data & Evidence Organization
     4. Self Study Report (SSR) Preparation (45-day window)
     5. Data Validation and Verification (DVV) Clarifications
     6. Student Satisfaction Survey (SSS) Execution
     7. Pre-Qualifier Score & Peer Team Visit (PTV)
     8. Results Declaration, Grading & Post-Accreditation AQARs
   - Persistent stage completion checkboxes, operational guidance, critical documents, and recommended Do's & Don'ts.

5. **Official Resource Center**
   - Direct links to authentic portals: NAAC Official Portal (`naac.gov.in`), HEI Assessment Portal, UGC, and AISHE.
   - Official RAF manuals, DVV SOPs, IQAC establishment booklets, and AQAR formats.
   - Filter by Manual, Guideline, Circular, Format, Portal.
   - Bookmark resources for instant access.

6. **Search & FAQ Hub**
   - Comprehensive indexed repository of frequently asked questions across 8 categories.
   - Instant search with search history management.
   - Direct "Ask AI about this" button for deep-dive answers.

7. **User Authentication & Role-Based Profiles**
   - Pre-configured 1-click test roles:
     - **NAAC Coordinator** (`coordinator@college.edu`)
     - **IQAC Member** (`iqac@college.edu`)
     - **Administrator** (`admin@college.edu`)
     - **Faculty** (`faculty@college.edu`)
   - Profile management and registration.

8. **Admin Dashboard & Analytics**
   - Live query consultation feed and helpfulness feedback metrics.
   - Multilingual query distribution (EN/HI/MR).
   - Evidence documentation readiness statistics.
   - Official notice and circular publishing manager.

---

## 🛠 Technology Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS, Lucide Icons, jsPDF
- **Backend:** Node.js, Express, tsx
- **AI Engine:** Google GenAI TypeScript SDK (`@google/genai`) with model `gemini-3.8-flash`
- **Persistence:** Local JSON file database (`./data/db.json`) with auto-seeding

---

## ⚙️ Environment Variables

Create a `.env` file or verify runtime secrets:

```env
# Required for Gemini AI API calls (server-side only)
GEMINI_API_KEY="your-api-key-here"

# Application hosting URL (injected automatically in AI Studio)
APP_URL="http://localhost:3000"

# Server port (default: 3000)
PORT=3000
```

*Note: The Gemini API key is accessed exclusively on the server and is never exposed to the client bundle.*

---

## 🚀 Running the Application

### 1. Installation
```bash
npm install
```

### 2. Development Mode
Runs the Express backend with embedded Vite middleware on port 3000:
```bash
npm run dev
```

### 3. Build & Production
```bash
npm run build
npm start
```

---

## 🔒 Security & Privacy

- Server-side Gemini API calls ensure private keys are never transmitted to the browser.
- Sanitized input and structured error boundaries.
- User data and checklist items are stored with server-side validation.
- Clear disclaimers indicating that the application is an independent educational tool and not an official branch of NAAC.

---

## ⚠️ Known Limitations & Disclaimer

- **Independent Tool:** This bot is an educational assistant and is **not** affiliated with NAAC or UGC. Institutions must always refer to the latest manuals and notifications on [www.naac.gov.in](https://www.naac.gov.in).
- **Evolving Reforms:** Frameworks such as Binary Accreditation and Maturity-based Graded Accreditation are subject to national rollout timelines. Check official notifications for the current cycle applicable to your institution.
